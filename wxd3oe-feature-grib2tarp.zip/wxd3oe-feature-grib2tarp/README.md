# BOSkit — Integrated Forecast Operations Suite

End-to-end weather forecast workflow for tactical aviation operations. From raw surface observations and ML bias correction through TAF generation, 5-day planning, and verification grading — all offline-capable, browser-native tools.

[![pipeline status](https://sync.git.mil/john.delaney.7/wxd3oe/badges/main/pipeline.svg)](https://sync.git.mil/john.delaney.7/wxd3oe/-/pipelines)

---

## Description

BOSkit is a suite of browser-based weather operations tools designed for Base Operations Squadrons supporting tactical flight operations. Every tool runs entirely in the browser — no server, no backend, no internet connection required at runtime. Files never leave your machine.

The suite covers the full forecast workflow:

| Step | Tool | Purpose |
|------|------|---------|
| 1 | [AF Form 3803](af_form_3803.html) | Collect and export structured surface weather observations |
| 2 | [ML Bias Corrector](ml_trainer.html) | Train a neural network to correct systematic TARP model errors |
| 3 | [TAF Generator](taf_generator_v2_intellisense.html) | Build AFMAN 15-124 compliant TAFs with IntelliSense and ML-corrected TARP guidance |
| 4 | [5-Day Forecast](5day_forecast_tool.html) | Grid-based planning display with RAG asset impact assessment |
| 5 | [WX Grade](wx_grade.html) | Verify forecasts against observations and score A–F by variable |

Additional tools:

| Tool | Category | Purpose |
|------|----------|---------|
| [MEF Tool](mef_tool.html) | Pilot Briefing | Mission Execution Forecast builder — stages from TARP, editable paper, print-ready |
| [TARP Meteogram](meteogram.html) | Visualization | Upper-air/surface cross-section from TARP CSV |
| [TAF Monitor](taf_monitor.html) | Monitoring | Live TAF expiry countdowns and amendment status board |
| [Asset Manager](asset_manager.html) | Configuration | GUI editor for aircraft thresholds and `config.json` |
| [WWA Manager](wwa_tool.html) | Situational Awareness | Watches, Warnings & Advisories dashboard with expiry alerts |
| [DAFIF Map](dafif_map.html) | Airspace & Navigation | Interactive plot of DAFIF airports, navaids, and waypoints |
| [Weather Draw](weather_draw.html) | Analysis | Map-based weather drawing — fronts, SIGWX, GeoJSON/KMZ export |
| [Skew-T Sounding](skewt/SkewT.htm) | Analysis | Thermodynamic diagram with CAPE/CIN, LCL/LFC, and aviation hazard indices |
| [DD Form 175-1](af175_tool.html) | Briefing | Digital flight weather briefing form pre-filled from TARP CSV |
| [GFS Downloader](gfs_downloader.html) | Data | Download GFS model data by region, level, and forecast hour |

---

## Installation

BOSkit requires no installation. Clone the repository and open `index.html`.

```bash
git clone https://sync.git.mil/john.delaney.7/wxd3oe.git
cd wxd3oe
# Open index.html in Chrome, Edge, or Firefox
```

If your browser restricts local file access, serve from a local web server:

```bash
python3 -m http.server 8080
# Open http://localhost:8080
```

For intranet deployment, copy the entire directory to any static web server (Apache, Nginx, IIS). No server-side configuration is required.

### Offline ML Setup

TensorFlow.js (`js/tf.min.js`) is included for offline use. No CDN access is needed for the ML Bias Corrector or MEF Tool ML features.

---

## Usage

### Typical Forecast Workflow

```
AF Form 3803        collect surface observations → export JSON
       ↓
ML Bias Corrector   load obs + TARP CSV → train model → export model.json + ml_meta.json
       ↓
TAF Generator       load TARP CSV + model → write and validate TAFs
       ↓
MEF Tool            load TARP CSV + TAFs + config → stage MEF paper → print
       ↓
WX Grade            load TAFs + METARs → grade A–F → export report
```

### Data File Conventions

| Directory | Contents |
|-----------|----------|
| `obs_data/` | AF Form 3803 JSON exports and raw METAR text files |
| `tarp_data/` | TARP forecast CSV files (named by station + model run time) |
| `ml_model/` | Trained model files (`model.json`, `model.weights.bin`, `ml_meta.json`) |

### Session Persistence

All tools auto-save working state to `localStorage`. Work survives a page reload on the same machine and browser. Use each tool's **Save JSON** or **Export** function to create portable backups.

---

## Dependencies

All dependencies are vendored locally under `js/` — no CDN required.

| Library | Version | Used by |
|---------|---------|---------|
| TensorFlow.js | 4.17.0 | ML Bias Corrector, MEF Tool |
| D3.js | v7 | Meteogram, Weather Draw, Skew-T |
| TopoJSON | v3 | DAFIF Map, Weather Draw |
| DOMPurify | — | TAF Generator, MEF Tool (input sanitization) |
| Bootstrap | — | General layout |

---

## Security

Static Application Security Testing (SAST) and Secret Detection run automatically on every push via GitLab CI. Results are available in **Security → Vulnerability Report** (GitLab Ultimate) or as `gl-sast-report.json` pipeline artifacts (Free/Premium).

See [CI-CD wiki page](../../wikis/CI-CD) for runner setup and pipeline details.

---

## Support

Open an issue in the [project issue tracker](https://sync.git.mil/john.delaney.7/wxd3oe/-/issues) or consult the [project wiki](https://sync.git.mil/john.delaney.7/wxd3oe/-/wikis/home) for detailed per-tool documentation.

---

## Contributing

1. Fork the project and create a feature branch
2. Make changes — all tools are single self-contained HTML files with inline CSS and JS
3. Open a merge request against `main`
4. SAST pipeline must pass before merge

There are no build steps or package managers. Each tool is a standalone `.html` file.

---

## Authors

- **john.delaney.7** — project author and maintainer

---

## License

Distribution authorized to DoD personnel only. See your unit security officer for handling requirements.

---

## Project Status

Active development. Core forecast workflow tools (Steps 1–5) are production-ready. See the [issue tracker](https://sync.git.mil/john.delaney.7/wxd3oe/-/issues) for planned enhancements.
