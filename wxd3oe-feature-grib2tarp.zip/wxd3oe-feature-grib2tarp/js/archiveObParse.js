/**
 * --- NEW ASYNC/AWAIT COMPATIBLE FUNCTION ---
 * Opens a file dialog for the user to select a text or .ob file,
 * then parses it asynchronously.
 * Returns a Promise that resolves with the parsed atmospheric data or rejects with an error.
 * @returns {Promise<object>} A Promise that resolves with an object containing metadata and profile data.
 */
function openAndParseObAsync() {
    // This function wraps the entire file-reading and parsing operation in a Promise.
    return new Promise((resolve, reject) => {
        // 1. Create a temporary, hidden file input element
        const fileInput = document.createElement('input');
        fileInput.type = 'file';
        fileInput.accept = '.txt,.ob'; // Accept .txt and .ob files
        fileInput.style.display = 'none';

        // 2. Define the action to take when a file is selected
        fileInput.onchange = (event) => {
            const file = event.target.files[0];
            if (!file) {
                // If the user cancels the file dialog, reject the promise.
                return reject(new Error("No file selected."));
            }

            const reader = new FileReader();

            // 3. Define what happens when the file has been successfully read
            reader.onload = (e) => {
                const content = e.target.result;
                try {
                    // ...parse the raw text content...
                    const parsedData = parseAtmosphericData(content);
                    // ...create the final 2D array...
                    const profile2D = create2DProfileArray(parsedData);
                    
                    // ...and RESOLVE the promise with the complete, processed result.
                    resolve({
                        metadata: parsedData.metadata,
                        profile: parsedData.profile,
                        processedProfile: profile2D
                    });

                } catch (error) {
                    // If any part of the parsing fails, REJECT the promise.
                    reject(error);
                } finally {
                    // Clean up the temporary input element from the document
                    document.body.removeChild(fileInput);
                }
            };

            // If there's an error reading the file itself...
            reader.onerror = () => {
                reject(new Error("Error reading the file."));
                document.body.removeChild(fileInput);
            };

            // 4. Start reading the selected file as text
            reader.readAsText(file);
        };

        // 5. Add the input element to the document and programmatically click it to open the file dialog
        document.body.appendChild(fileInput);
        fileInput.click();
    });
}


/**
 * Parses atmospheric data from a raw text file.
 *
 * The function identifies and extracts two main sections:
 * 1.  A profile of atmospheric measurements at different altitudes.
 * 2.  A set of metadata about the observation station.
 *
 * @param {string} data The raw text content of the atmospheric data file.
 * @returns {{metadata: object, profile: Array<object>}} An object containing the parsed metadata and profile data.
 */
function parseAtmosphericData(data) {
    const lines = data.split('\n');
    const profile = [];
    const metadata = {};
    let isProfileSection = false;
    let isMetadataSection = false;

    // The headers for the atmospheric data profile
    const profileHeaders = ['PRES', 'HGHT', 'TEMP', 'DWPT', 'RELH', 'MIXR', 'DRCT', 'SKNT', 'THTA', 'THTE', 'THTV'];

    // Mapping of metadata keys from the file to desired keys in the output object
    const metadataMapping = {
        'Station identifier': 'stationIdentifier',
        'Station number': 'stationNumber',
        'Observation time': 'observationTime',
        'Station latitude': 'latitude',
        'Station longitude': 'longitude',
        'Station elevation': 'elevation'
    };
    const desiredMetadataKeys = Object.keys(metadataMapping);

    for (const line of lines) {
        // Switch to profile parsing mode after the header separator
        if (line.includes('-----------------------------------------------------------------------------')) {
            isProfileSection = true;
            continue;
        }

        // Switch to metadata parsing mode when this header is found
        if (line.includes('Station information and sounding indices')) {
            isProfileSection = false;
            isMetadataSection = true;
            continue;
        }

        // --- Profile Data Parsing ---
        if (isProfileSection) {
            const trimmedLine = line.trim();
            if (!trimmedLine) continue; // Skip empty lines

            const values = trimmedLine.split(/\s+/);

            const levelData = {};
            // Lines with fewer than 11 columns are considered "below surface"
            if (values.length < 11) {
                levelData.PRES = parseFloat(values[0]);
                if (values.length > 1) {
                    levelData.HGHT = parseFloat(values[1]);
                }
                levelData.isBelowSurface = true;
                profile.push(levelData);
            } else {
                // Full data lines
                profileHeaders.forEach((header, index) => {
                    levelData[header] = parseFloat(values[index]);
                });
                levelData.isBelowSurface = false;
                profile.push(levelData);
            }
        }

        // --- Metadata Parsing ---
        if (isMetadataSection) {
            const parts = line.split(':');
            if (parts.length === 2) {
                const key = parts[0].trim();
                if (desiredMetadataKeys.includes(key)) {
                    const newKey = metadataMapping[key];
                    let value = parts[1].trim();

                    // Convert numeric metadata values to numbers
                    if (newKey !== 'observationTime' && newKey !== 'stationIdentifier') {
                       value = parseFloat(value);
                    }
                    metadata[newKey] = value;
                }
            }
        }
        
        // Stop metadata parsing at the end of the metadata block
        if (line.includes('</PRE>')) {
             if(isMetadataSection) {
                isMetadataSection = false;
             }
        }
    }

    // Mark the first full data level as the "surface"
    const surfaceIndex = profile.findIndex(p => !p.isBelowSurface);
    if (surfaceIndex !== -1) {
        profile[surfaceIndex].isSurface = true;
    }

    return { metadata, profile };
}

/**
 * Performs linear interpolation for a value.
 * @param {number} x - The point to find the value for (target pressure).
 * @param {number} x1 - The x-coordinate of the first known point (pressure 1).
 * @param {number} x2 - The x-coordinate of the second known point (pressure 2).
 * @param {number} y1 - The y-coordinate of the first known point (e.g., temp 1).
 * @param {number} y2 - The y-coordinate of the second known point (e.g., temp 2).
 * @returns {number|null} The interpolated value, or null if interpolation is not possible.
 */
function linearInterpolate(x, x1, x2, y1, y2) {
    if (x1 === x2) return y1;
    if (typeof y1 !== 'number' || typeof y2 !== 'number') return null;
    return y1 + (x - x1) * (y2 - y1) / (x2 - x1);
}

/**
 * Finds bracketing data points and interpolates a full atmospheric level for a target pressure.
 * @param {number} targetPres - The pressure level to calculate data for (e.g., 900, 875).
 * @param {Array<object>} fullDataProfile - The filtered profile array containing only full data levels.
 * @returns {object|null} An object with all interpolated atmospheric parameters, or null if not possible.
 */
function getInterpolatedLevel(targetPres, fullDataProfile) {
    let level1 = null; // Point below the target altitude (higher pressure)
    let level2 = null; // Point above the target altitude (lower pressure)

    for (let i = 0; i < fullDataProfile.length - 1; i++) {
        // Find the two levels in the source data that bracket our target pressure
        if (fullDataProfile[i].PRES >= targetPres && fullDataProfile[i + 1].PRES < targetPres) {
            level1 = fullDataProfile[i];
            level2 = fullDataProfile[i + 1];
            break;
        }
    }

    if (!level1 || !level2) {
        return null; // Cannot interpolate if bracketing levels are not found
    }

    const interpolated = { PRES: targetPres };
    const paramsToInterpolate = ['HGHT', 'TEMP', 'DWPT', 'RELH', 'DRCT', 'SKNT'];

    for (const param of paramsToInterpolate) {
        interpolated[param] = linearInterpolate(targetPres, level1.PRES, level2.PRES, level1[param], level2[param]);
    }
    
    return interpolated;
}

/**
 * Creates a 2D array from the parsed profile data with interpolated values at 25mb increments.
 * @param {object} parsedData - The object returned from the parseAtmosphericData function.
 * @returns {Array<Array<any>>} A 2D array containing headers and the processed profile data.
 */
function create2DProfileArray(parsedData) {
    const { profile } = parsedData;

    const surfaceLevel = profile.find(p => p.isSurface);
    if (!surfaceLevel) {
        console.error("Surface level not found in the provided data.");
        return [];
    }
    const stationElevation = surfaceLevel.HGHT; // Elevation (MSL) at the surface for AGL calculations.

    const profile2D = [];
    //const headers = ['PRES', 'HGHT (MSL)', 'HGHT (AGL)', 'TEMP', 'DWPT', 'RELH', 'DRCT', 'SKNT'];
    //profile2D.push(headers);

    // Add the surface level data as the first row
    const surfaceRow = [
        surfaceLevel.PRES,
        surfaceLevel.HGHT,
        0, // AGL at the surface is always 0
        surfaceLevel.TEMP,
        surfaceLevel.DWPT,
        surfaceLevel.RELH,
        surfaceLevel.DRCT,
        surfaceLevel.SKNT
    ];
    profile2D.push(surfaceRow);

    // Filter out below-surface levels for interpolation
    const fullDataProfile = profile.filter(p => !p.isBelowSurface);
    const minPressureInProfile = fullDataProfile.length > 0 ? fullDataProfile[fullDataProfile.length - 1].PRES : 0;

    // Start from the next 25mb increment below the surface pressure
    let currentPres = Math.floor(surfaceLevel.PRES / 25) * 25;

    while (currentPres >= minPressureInProfile && currentPres > 0) {
        const interpolatedLevel = getInterpolatedLevel(currentPres, fullDataProfile);

        if (interpolatedLevel) {
            const agl = interpolatedLevel.HGHT - stationElevation;
            const newRow = [
                interpolatedLevel.PRES,
                interpolatedLevel.HGHT,
                agl,
                interpolatedLevel.TEMP,
                interpolatedLevel.DWPT,
                interpolatedLevel.RELH,
                interpolatedLevel.DRCT,
                interpolatedLevel.SKNT
            ];
            // Round numbers to 2 decimal places for cleaner output
            const roundedRow = newRow.map(val => (typeof val === 'number' ? parseFloat(val.toFixed(1)) : val));
            profile2D.push(roundedRow);
        }
        currentPres -= 25; // Move to the next 25mb level up
    }

    return profile2D;
}
