/**
 * --- NEW ASYNC/AWAIT COMPATIBLE FUNCTION ---
 * Returns a Promise that resolves with the parsed JSON data or rejects with an error.
 * @returns {Promise<object>} A Promise that resolves with the parsed BUFKIT data.
 */
function openAndParseBufkitAsync() {
    // This function wraps the entire operation in a Promise.
    return new Promise((resolve, reject) => {
        // 1. Create a temporary, hidden file input element
        const fileInput = document.createElement('input');
        fileInput.type = 'file';
        fileInput.accept = '.buf,.txt';
        fileInput.style.display = 'none';

        // 2. Define the action to take when a file is selected
        fileInput.onchange = (event) => {
            const file = event.target.files[0];
            if (!file) {
                // If the user cancels, reject the promise.
                return reject(new Error("No file selected."));
            }

            const reader = new FileReader();

            // When the file is read...
            reader.onload = (e) => {
                const content = e.target.result;
                try {
                    // ...parse the content...
                    const finalJson = parseBufkitFile(content);
                    // ...and RESOLVE the promise with the successful result.
                    resolve(finalJson);
                } catch (error) {
                    // If parsing fails, REJECT the promise with the error.
                    reject(error);
                } finally {
                    // Clean up the temporary input element
                    document.body.removeChild(fileInput);
                }
            };

            // If there's an error reading the file...
            reader.onerror = () => {
                reject(new Error("Error reading file."));
                document.body.removeChild(fileInput);
            };

            // Start reading the file
            reader.readAsText(file);
        };

        // 3. Add the input to the document and programmatically click it
        document.body.appendChild(fileInput);
        fileInput.click();
    });
}

function parseBufkitFile(content) {
    const metadata = parseMetadata(content);
    const surfaceHeaderMarker = 'STN YYMMDD/HHMM';
    const splitIndex = content.indexOf(surfaceHeaderMarker);
    const profileContent = splitIndex === -1 ? content : content.substring(0, splitIndex);
    const surfaceContent = splitIndex === -1 ? '' : content.substring(splitIndex);
    const profilesByStim = parseProfileSection(profileContent);
    const surfaceDataList = parseSurfaceSection(surfaceContent);
    const wxdata = surfaceDataList.map((surfaceRecord, index) => {
        const stim = index;
        const profile = profilesByStim[stim] || [];
        return { ...surfaceRecord, profile: profile };
    });
    return { metadata: metadata, wxdata: wxdata };
}

function parseMetadata(content) {
    const metadata = {};
    const lines = content.split('\n');
    const stidLine = lines.find(line => line.includes('STID ='));
    if (stidLine) {
        metadata.stationId = stidLine.match(/STID\s*=\s*(\S+)/)?.[1];
        metadata.stationNumber = parseInt(stidLine.match(/STNM\s*=\s*(\d+)/)?.[1], 10);
    }
    const slatLine = lines.find(line => line.includes('SLAT ='));
    if (slatLine) {
        metadata.latitude = parseFloat(slatLine.match(/SLAT\s*=\s*([-\d.]+)/)?.[1]);
        metadata.longitude = parseFloat(slatLine.match(/SLON\s*=\s*([-\d.]+)/)?.[1]);
        metadata.elevation = parseFloat(slatLine.match(/SELV\s*=\s*([-\d.]+)/)?.[1]);
    }
    return metadata;
}

function parseProfileSection(content) {
    const timeBlocks = content.split('STID =').slice(1);
    const parsedData = {};
    timeBlocks.forEach(block => {
        const lines = block.trim().split('\n');
        const stimMatch = block.match(/STIM\s*=\s*(\d+)/);
        if (!stimMatch) return;
        const stim = parseInt(stimMatch[1], 10);
        let header1Index = lines.findIndex(line => line.includes('PRES') && line.includes('TMPC'));
        if (header1Index === -1) return;
        const columnHeaders = [...lines[header1Index].trim().split(/\s+/), ...lines[header1Index + 1].trim().split(/\s+/)];
        const dataStartIndex = header1Index + 2;
        const recordsForThisHour = [];
        for (let i = dataStartIndex; i < lines.length; i += 2) {
            if (i + 1 >= lines.length) break;
            const line1 = lines[i].trim();
            const line2 = lines[i+1].trim();
            if (line1 === '' || isNaN(parseFloat(line1.split(/\s+/)[0]))) break;
            const values = `${line1} ${line2}`.trim().split(/\s+/);
            const levelRecord = {};
            columnHeaders.forEach((header, colIndex) => {
                levelRecord[header] = values[colIndex] ? parseFloat(values[colIndex]) : null;
            });
            recordsForThisHour.push(levelRecord);
        }
        if (recordsForThisHour.length > 0) {
            // Sort by descending PRES (bottom to top: high PRES first)
            recordsForThisHour.sort((a, b) => b.PRES - a.PRES);

            // Adjust invalid DWPC values
            let last_depression = null;
            for (let record of recordsForThisHour) {
                const tmpc = record.TMPC;
                let dwpc = record.DWPC;
                if (!isNaN(tmpc) && !isNaN(dwpc) && dwpc !== -9999.00) {
                    last_depression = tmpc - dwpc;
                } else if (dwpc === -9999.00 && !isNaN(tmpc) && last_depression !== null) {
                    const new_depression = last_depression + 10;
                    record.DWPC = tmpc - new_depression;
                }
                // else leave as is
            }

            parsedData[stim] = recordsForThisHour;
        }
    });
    return parsedData;
}

function parseSurfaceSection(content) {
    if (!content) return [];
    const lines = content.trim().split('\n');
    let dataStartIndex = -1;
    const headerLines = [];
    for (let i = 0; i < lines.length; i++) {
        if (/\d{6}\/\d{4}/.test(lines[i])) {
            dataStartIndex = i;
            break;
        }
        headerLines.push(lines[i]);
    }
    if (dataStartIndex === -1) return [];
    const columnHeaders = headerLines.join(' ').trim().split(/\s+/);
    const numLinesPerRecord = headerLines.length;
    const dataLines = lines.slice(dataStartIndex);
    const records = [];
    for (let i = 0; i < dataLines.length; i += numLinesPerRecord) {
        const recordChunk = dataLines.slice(i, i + numLinesPerRecord);
        if (recordChunk.length < numLinesPerRecord) continue;
        const values = recordChunk.map(line => line.trim()).join(' ').trim().split(/\s+/);
        if (values.length < columnHeaders.length) continue;
        const record = {};
        columnHeaders.forEach((header, index) => {
            record[header] = (header === 'YYMMDD/HHMM') ? values[index] : parseFloat(values[index]);
        });
        records.push(record);
    }
    return records;
}

function build3DArray(parsedData) {
    const data3D = [];
    const elev = parsedData.metadata.elevation || 0; // Default to 0 if missing
    parsedData.wxdata.forEach((wx) => {
        const timeSlice = [];

        // Surface level 0
        const u = wx['UWND'] || 0;
        const v = wx['VWND'] || 0;
        const speed = Math.sqrt(u * u + v * v);
        let dir = Math.atan2(-u, -v) * (180 / Math.PI);
        dir = (dir + 360) % 360;

        const surface = [];
        surface.push(wx['PRES'] || NaN); // pressure
        surface.push(Math.round(elev)); // msl
        surface.push(0); // agl
        surface.push(wx['TMPC'] || wx['T2MS'] || NaN); // temp C (use TMPC if available, else T2MS)
        surface.push(wx['TD2M'] || NaN); // dew C
        surface.push(0); // omega
        surface.push(dir);
        surface.push(speed);
        timeSlice.push(surface);

        // Build original levels including surface for interpolation
        const origLevels = [];
        const surfaceLevel = {
            PRES: wx['PRES'] || NaN,
            HGHT: elev,
            TMPC: wx['TMPC'] || wx['T2MS'] || NaN,
            DWPC: wx['TD2M'] || NaN,
            OMEG: 0,
            DRCT: dir,
            SKNT: speed
        };
        origLevels.push(surfaceLevel);

        wx.profile.forEach((level) => {
            origLevels.push({
                PRES: level['PRES'],
                HGHT: level['HGHT'],
                TMPC: level['TMPC'],
                DWPC: level['DWPC'],
                OMEG: level['OMEG'],
                DRCT: level['DRCT'],
                SKNT: level['SKNT']
            });
        });

        // Sort by PRES descending (just in case)
        origLevels.sort((a, b) => b.PRES - a.PRES);

        // Remove any duplicates or invalid
        const filteredOrigLevels = origLevels.filter(level => !isNaN(level.PRES));

        // Calculate minP
        const minP = Math.min(...filteredOrigLevels.map(l => l.PRES));

        // Calculate first interpolated P
        const surfacePres = wx['PRES'] || NaN;
        if (isNaN(surfacePres)) {
            data3D.push(timeSlice); // Only surface if no pres
            return;
        }
        const mod = surfacePres % 25;
        let firstP = mod === 0 ? surfacePres - 25 : surfacePres - mod;

        // Generate p_targets
        const pTargets = [];
        let currentP = firstP;
        while (currentP >= Math.max(minP, 25)) { // Floor at 25 hPa to avoid too many levels
            pTargets.push(currentP);
            currentP -= 25;
        }

        // Interpolate for each p_target
        pTargets.forEach((targetP) => {
            const hght = interpolate(filteredOrigLevels, 'HGHT', targetP);
            const temp = interpolate(filteredOrigLevels, 'TMPC', targetP);
            const dew = interpolate(filteredOrigLevels, 'DWPC', targetP);
            const omega = interpolate(filteredOrigLevels, 'OMEG', targetP);
            let windDir = interpolate(filteredOrigLevels, 'DRCT', targetP);
            const windSpeed = interpolate(filteredOrigLevels, 'SKNT', targetP);

            // Handle wind direction wrapping (simple approach)
            if (!isNaN(windDir)) {
                windDir = (windDir + 360) % 360;
            }

            const agl = !isNaN(hght) ? hght - elev : NaN;

            const level = [
                targetP,
                Math.round(hght),
                Math.round(agl),
                temp,
                dew,
                omega,
                windDir,
                windSpeed
            ];
            timeSlice.push(level);
        });

        data3D.push(timeSlice);
    });
    return data3D;
}

function interpolate(levels, varName, targetP) {
    for (let i = 0; i < levels.length - 1; i++) {
        const p1 = levels[i].PRES;
        const p2 = levels[i + 1].PRES;
        if (p1 >= targetP && targetP >= p2) {
            const v1 = levels[i][varName];
            const v2 = levels[i + 1][varName];
            if (isNaN(v1) || isNaN(v2)) return NaN;
            const frac = (p1 - targetP) / (p1 - p2);
            return v1 * (1 - frac) + v2 * frac; // Corrected interpolation formula
        }
    }
    return NaN; // Out of range or no data
}

function getMetadata(parsedData) {
    return parsedData.metadata || {};
}

function getFirstDateTime(parsedData) {
    if (parsedData.wxdata && parsedData.wxdata.length > 0) {
        return parsedData.wxdata[0]['YYMMDD/HHMM'] || 'Unknown';
    }
    return 'No data available';
}

function getAllValidTimes(parsedData) {
    let fcstTimes = []
    for (let i = 0; i < parsedData.wxdata.length - 1; i++) {
        fcstTimes.push(parsedData.wxdata[i]['YYMMDD/HHMM'] || 'UNKN');
    }
    return fcstTimes;
}

function formatDateToUTC_bufdate(dateString) {
    if (typeof dateString !== 'string') {
        return null;
    }
    try {
        const day = parseInt(dateString.substring(4, 6), 10);
        const month = parseInt(dateString.substring(2, 4), 10) - 1; // Month is 0-indexed in JS (0-11)
        const year = 2000 + parseInt(dateString.substring(0, 2), 10); // Assuming 21st century
        const hour = parseInt(dateString.substring(7, 9), 10);
        const date = new Date(Date.UTC(year, month, day, hour));
        if (isNaN(date)) return null;
        return date.toISOString();
    } catch (e) {
        return null;
    }
}
