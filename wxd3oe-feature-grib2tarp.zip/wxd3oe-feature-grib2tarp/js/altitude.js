/**
 * A dedicated class to manage and calculate Pressure and Density Altitude for multiple tables.
 * This version is robustly designed to handle multiple table layouts, including multiple <thead>
 * and <tbody> elements, and only calculates on user input for the edited row.
 */
class AltitudeCalculator {
    /**
     * @param {string[]} tableIds An array of table element IDs to attach the calculator to.
     */
    constructor(tableIds) {
        if (!tableIds || !tableIds.length) {
            console.warn("AltitudeCalculator: No table IDs were provided.");
            return;
        }

        tableIds.forEach(id => {
            const tableElement = document.getElementById(id);
            if (!tableElement) {
                console.warn(`AltitudeCalculator: Table with ID "${id}" not found.`);
                return;
            }

            // --- Step 1: Find Elevation (works for both layouts) ---
            const elevationHeader = tableElement.querySelector('.elevation.hd');
            let elevation = 0;
            if (elevationHeader) {
                const match = elevationHeader.textContent.match(/ELEV\s*(\d+)/i);
                elevation = match && match[1] ? parseInt(match[1], 10) : 0;
            } else {
                console.warn(`AltitudeCalculator: Elevation header (.elevation.hd) not found in table "${id}".`);
            }

            // --- Step 2: Flexibly find the header row with titles (works for both layouts) ---
            const firstTitleHeader = tableElement.querySelector('th.titles');
            if (!firstTitleHeader) {
                console.warn(`AltitudeCalculator: No title headers ('th.titles') found in table "${id}".`);
                return;
            }
            const headerRow = firstTitleHeader.closest('tr');
            
            const headerMap = {};
            headerRow.querySelectorAll('th.titles').forEach((th, index) => {
                const headerText = th.textContent.trim();
                if (['TEMP', 'ALSTG', 'PA', 'DA'].includes(headerText)) {
                    headerMap[headerText] = index;
                }
            });

            if (!('TEMP' in headerMap && 'ALSTG' in headerMap && 'PA' in headerMap && 'DA' in headerMap)) {
                console.warn(`AltitudeCalculator: Required columns (TEMP, ALSTG, PA, DA) not found in table "${id}".`);
                return;
            }
            
            const tableData = {
                elevation: elevation,
                headerMap: headerMap
            };

            // --- Step 3: Use Event Delegation on the whole table (works for both layouts) ---
            tableElement.addEventListener('input', (event) => {
                // Check if the edit happened in a cell (TD)
                if (event.target && event.target.tagName === 'TD') {
                    const row = event.target.closest('tr');
                    // We need to pass both the specific row and the table's configuration
                    if (row) {
                        this.recalculateRow(row, tableData);
                    }
                }
            });
        });
    }

    /**
     * Performs PA/DA calculations for a single, specific row.
     * @param {HTMLTableRowElement} row The table row to perform calculations on.
     * @param {object} tableData The configuration object for the table this row belongs to.
     */
    recalculateRow(row, tableData) {
        const { elevation, headerMap } = tableData;

        const cells = row.querySelectorAll('td');
        const tempCell = cells[headerMap['TEMP']];
        const alstgCell = cells[headerMap['ALSTG']];
        const paCell = cells[headerMap['PA']];
        const daCell = cells[headerMap['DA']];

        if (!tempCell || !alstgCell || !paCell || !daCell) {
            return;
        }

        const tempC = parseFloat(tempCell.textContent) || 0;
        const altimeterSetting = parseFloat(alstgCell.textContent) || 29.92;

        const pressureAltitude = Math.round(calculatePressureAltitude(elevation,altimeterSetting));
        const isaTempC = 15 - (2 * (elevation / 1000));
        const densityAltitude = Math.round(pressureAltitude + (120 * (tempC - isaTempC)));

        paCell.textContent = pressureAltitude >= 0 ? `+${pressureAltitude}` : pressureAltitude.toString();
        daCell.textContent = densityAltitude >= 0 ? `+${densityAltitude}` : densityAltitude.toString();
    }
}

function calculatePressureAltitude(indicatedAltitude, altimeterSetting) {
  // Standard pressure in inches of mercury
  const standardPressure = 29.92126;

  // The exponent from the formula
  const exponent = 0.190261;

  // The pressure factor constant from the formula
  const pressureFactor = 145442.2;

  // Calculate the pressure altitude using the provided formula
  const pressureAltitude = indicatedAltitude + pressureFactor * (1 - Math.pow(altimeterSetting / standardPressure, exponent));

  return pressureAltitude;
}
