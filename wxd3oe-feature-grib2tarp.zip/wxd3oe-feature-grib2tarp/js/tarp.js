// =============================================================================
// tarp.js  —  TARP CSV parser and URL generator for the MEF tool
//
// Defines a global `parser` object:
//   parser.parsedResults   Array of { ICAO: { metadata, timeseries } }
//   parser.processFile(f)  Parse one TARP CSV File object and push the result
//
// Wires:
//   #csvFileInput   → parser.processFile for each selected file
//   configLoaded    → populate #urls-list with download links
// =============================================================================

'use strict';

// ── TARP CSV parser ──────────────────────────────────────────────────────────

const parser = (() => {

    const _results = [];

    /**
     * Derive the ICAO from the file name.
     * Expects a name like  KSSC_TARP_forecast_data.csv  or
     *                      KSSC_TARP_forecast_data_2025-06-02T06_00_00Z.csv
     */
    function _icaoFromName(filename) {
        const m = filename.match(/^([A-Z0-9]{3,6})_/i);
        return m ? m[1].toUpperCase() : filename.replace(/\.[^.]+$/, '').toUpperCase();
    }

    /**
     * Parse a single TARP CSV text string.
     * Returns { ICAO: { metadata, timeseries } } or null on failure.
     */
    function _parse(text, filename) {
        const lines = text.split(/\r?\n/);
        const meta  = { name: '', latitude: 0, longitude: 0, elevation: 0, runways: [], model_run: '' };
        let   hours = [];
        const rows  = [];

        for (const raw of lines) {
            const line = raw.trim();
            if (!line) continue;

            if (line.startsWith('#')) {
                // Metadata comment: "# key: value"
                const m = line.slice(1).match(/^\s*([^:]+):\s*(.+)$/);
                if (!m) continue;
                const key = m[1].trim().toLowerCase();
                const val = m[2].trim();
                switch (key) {
                    case 'name':      meta.name      = val; break;
                    case 'latitude':  meta.latitude  = parseFloat(val); break;
                    case 'longitude': meta.longitude = parseFloat(val); break;
                    case 'elevation': meta.elevation = parseFloat(val); break;
                    case 'model_run': meta.model_run = val; break;
                    case 'runways':
                        meta.runways = val.replace(/[\[\]]/g, '').split(',').map(v => parseInt(v.trim())).filter(n => !isNaN(n));
                        break;
                }
                continue;
            }

            const cells = line.split(',');

            // First data line is the hour header: "",0,1,2,…
            if (hours.length === 0 && cells[0].trim() === '') {
                hours = cells.slice(1).map(v => parseInt(v.trim()));
                continue;
            }

            // Parameter data row
            if (hours.length > 0 && cells[0].trim()) {
                rows.push(cells);
            }
        }

        if (!hours.length || !rows.length) return null;

        // Build timeseries array
        const timeseries = rows.map(cells => {
            const parameter = cells[0].trim();
            const values    = cells.slice(1).map((v, i) => ({
                hour:  hours[i] !== undefined ? hours[i] : i,
                value: parseFloat(v) || 0
            }));
            return { parameter, values };
        });

        const icao = _icaoFromName(filename);
        return { [icao]: { metadata: meta, timeseries } };
    }

    /**
     * Read a File object, parse it, and push the result into parsedResults.
     * Shows a brief status in #output if present.
     */
    function processFile(file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            const result = _parse(e.target.result, file.name);
            if (!result) {
                const out = document.getElementById('output');
                if (out) out.textContent = `Could not parse ${file.name}`;
                return;
            }
            _results.push(result);
            const out = document.getElementById('output');
            if (out) out.textContent = `Loaded: ${file.name}`;
        };
        reader.readAsText(file);
    }

    // ── Wire #csvFileInput ───────────────────────────────────────────────────
    document.addEventListener('DOMContentLoaded', () => {
        const input = document.getElementById('csvFileInput');
        if (input) {
            input.addEventListener('change', (e) => {
                // Clear previous results each time new files are chosen
                _results.length = 0;
                for (const file of e.target.files) {
                    parser.processFile(file);  // use the (potentially patched) method so UI updates fire
                }
                e.target.value = '';   // allow same file to be re-loaded
            });
        }
    });

    // ── Sounding profile builder (for Skew-T) ───────────────────────────────
    // TARP pressure levels, ordered surface → top (high pressure → low pressure)
    const _SOUNDING_LEVELS = [
        1000, 975, 950, 925, 900, 875, 850, 825, 800, 775, 750, 725, 700,
        675, 650, 625, 600, 575, 550, 525, 500, 475, 450, 425, 400, 375,
        350, 325, 300, 275, 250, 225, 200, 175, 150, 125, 100
    ];

    /**
     * Compute dewpoint (°C) from temperature (°C) and relative humidity (%).
     * Uses the Magnus formula.
     */
    function _dewpFromRH(tmpC, rh) {
        rh = Math.max(1, Math.min(100, rh));
        const gamma = Math.log(rh / 100) + (17.625 * tmpC) / (243.04 + tmpC);
        return (243.04 * gamma) / (17.625 - gamma);
    }

    /**
     * Estimate station pressure (hPa) from altimeter setting (inHg) and
     * station elevation (m) using the standard atmosphere.
     */
    function _altToStationPres(alt_inHg, elev_m) {
        const pSea = alt_inHg * 33.8639;
        return pSea * Math.pow((288.15 - 0.0065 * elev_m) / 288.15, 5.2559);
    }

    /**
     * Build the profData structure for the Skew-T from a single parsedResult.
     * Returns { [ICAO]: Array<hours> } where each hour is an Array<levels>
     * and each level is [pres_hPa, msl_m, agl_m, temp_C, dewp_C, rh, wdir, wspd].
     */
    function _buildProfDataEntry(result) {
        const icao = Object.keys(result)[0];
        const { metadata, timeseries } = result[icao];
        const elev = metadata.elevation || 0;

        if (!timeseries || !timeseries.length) return { [icao]: [] };

        // Build flat lookup map: parameter → values array (positional, matches hours)
        const paramMap = {};
        for (const entry of timeseries) {
            paramMap[entry.parameter] = entry.values.map(v => v.value);
        }
        const numHours = timeseries[0].values.length;
        const get = (param, i) => (paramMap[param] != null ? paramMap[param][i] : null);

        const profHours = [];
        for (let i = 0; i < numHours; i++) {
            const levels = [];

            // ── Surface level ────────────────────────────────────────────────
            const sfcAlt    = get('altimeter', i);
            const sfcTmpK   = get('2m_agl_tmp', i);
            const sfcDptK   = get('2m_agl_dpt', i);
            const sfcRh     = get('2m_agl_rh', i) ?? 0;
            const sfcWdir   = get('10m_agl_dir', i) ?? 0;
            const sfcWspd   = get('10m_agl_spd', i) ?? 0;

            const sfcPres = sfcAlt != null
                ? _altToStationPres(sfcAlt, elev)
                : 1013.25;
            const sfcTmpC = sfcTmpK != null ? sfcTmpK - 273.15 : 20;
            const sfcDptC = sfcDptK != null
                ? sfcDptK - 273.15
                : _dewpFromRH(sfcTmpC, sfcRh);

            levels.push([sfcPres, elev, 0, sfcTmpC, sfcDptC, sfcRh, sfcWdir, sfcWspd]);

            // ── Upper-air levels ─────────────────────────────────────────────
            for (const mb of _SOUNDING_LEVELS) {
                const key  = `${mb}mb`;
                const gph  = get(`gph_${key}`, i);
                const tmpK = get(`temp_${key}`, i);
                if (gph == null || tmpK == null) continue;
                if (gph < elev) continue;           // below station elevation

                const tmpC = tmpK - 273.15;
                const agl  = gph - elev;
                const rh   = get(`rh_${key}`, i) ?? 0;
                const wdir = get(`dir_${key}`, i) ?? 0;
                const wspd = get(`speed_${key}`, i) ?? 0;
                const dptC = rh > 0 ? _dewpFromRH(tmpC, rh) : tmpC - 30;

                levels.push([mb, gph, agl, tmpC, dptC, rh, wdir, wspd]);
            }

            profHours.push(levels);
        }

        return { [icao]: profHours };
    }

    return {
        get parsedResults() { return _results; },
        /** Sounding profile data for the Skew-T: Array<{ [ICAO]: hours[][] }> */
        get profData() { return _results.map(_buildProfDataEntry); },
        processFile
    };
})();

// ── URL list generator ───────────────────────────────────────────────────────

/**
 * When a config is loaded, populate #urls-list with download links for each
 * TOLD / SECTOR ICAO so the user knows which TARP files to retrieve.
 */
document.addEventListener('configLoaded', (e) => {
    const cfg  = e.detail;
    const list = document.getElementById('urls-list');
    if (!list) return;

    const model = (cfg.MODEL || 'galwem').toLowerCase();
    const icaos = new Set();

    if (cfg.TOLDS)   cfg.TOLDS.split(',').forEach(s => { if (s.trim()) icaos.add(s.trim().toUpperCase()); });
    if (cfg.SECTORS) cfg.SECTORS.forEach(s => { if (s && s.icao) icaos.add(s.icao.toUpperCase()); });

    if (!icaos.size) {
        list.innerHTML = '<p style="font-size:11px;color:#888">No TOLDS / Sectors configured.</p>';
        return;
    }

    const BASE = 'https://bifrost.afweather.mil/tarp/v1/stations/';
    const lines = [`<p style="font-size:11px;margin-bottom:6px">TARP download URLs (<strong>${model.toUpperCase()}</strong>):</p>`];
    for (const icao of icaos) {
        const url = `${BASE}${icao}/fulltarpoutput?output_format=csv&model=GALWEM`;
        lines.push(`<a class="url-item" href="${url}" target="_blank" rel="noopener">${url}</a>`);
    }

    list.innerHTML = lines.join('');
});
