class WeatherTableAnalyzer {

    /**
     * @param {string[]} tableIds - An array of table IDs to be analyzed.
     * @param {object} config - The configuration object.
     */
    constructor(tableIds, config) {
        this.config = config.config;
        this.analyzedTables = [];
        tableIds.forEach(id => {
            const tableElement = document.getElementById(id);
            if (!tableElement) {
                console.log(`Table with ID "${id}" not found.`);
                return;
            }
            const headerRow = tableElement.querySelectorAll('thead tr')[1];
            const tableBody = tableElement.querySelector('tbody');
            const headerMap = {};
            headerRow.querySelectorAll('th.titles').forEach((th, index) => {
                headerMap[th.textContent.trim()] = index;
            });
            const tableData = {
                id: id,
                element: tableElement,
                body: tableBody,
                headerMap: headerMap
            };
            this.analyzedTables.push(tableData);
            tableBody.addEventListener('input', (event) => {
                if (event.target && event.target.tagName === 'TD') {
                    this.updateTableAnalysis(tableData);
                }
            });
            
            // Add event handlers for manual color changes
            this.addManualColorSelection(tableData.body);
        });
        this.updateAllAnalyses();
    }

    /**
     * Adds a double-click event listener to each asset cell to allow manual color changes.
     * @param {HTMLElement} tableBody - The tbody element of the table.
     */
    addManualColorSelection(tableBody) {
        tableBody.addEventListener('dblclick', (event) => {
            const cell = event.target.closest('td[data-asset-name]');
            if (!cell) return;
            // Prevent the browser's default double-click behavior (e.g., text selection)
            event.preventDefault();
            event.stopPropagation();
            // Clean up any old dropdowns before creating a new one
            const existingSelect = document.getElementById('manual-color-select');
            if (existingSelect) {
                existingSelect.remove();
            }
            // Create the <select> element
            const select = document.createElement('select');
            select.id = 'manual-color-select';
            // Add the color options
            ['Green', 'Yellow', 'Red'].forEach(color => {
                const option = document.createElement('option');
                option.value = color;
                option.textContent = color;
                if (cell.classList.contains(color)) {
                    option.selected = true;
                }
                select.appendChild(option);
            });
            // --- Positioning Logic ---
            const rect = cell.getBoundingClientRect();
            Object.assign(select.style, {
                position: 'absolute',
                top: `${rect.top + window.scrollY}px`,
                left: `${rect.left + window.scrollX}px`,
                width: `${rect.width}px`,
                height: `${rect.height}px`,
                margin: '0',
                boxSizing: 'border-box',
                border: '2px solid blue', // Highlight for visibility
                font: 'inherit',
                fontSize: '1em'
            });
            // --- Simplified Event Handling ---
            // 1. On successful selection: Update color and remove dropdown.
            select.addEventListener('change', () => {
                cell.classList.remove('Green', 'Yellow', 'Red');
                cell.classList.add(select.value);
                if (select.parentNode) {
                    select.parentNode.removeChild(select);
                }
            });
            // 2. On ESC key press: Just remove the dropdown.
            select.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') {
                    if (select.parentNode) {
                        select.parentNode.removeChild(select);
                    }
                }
            });
            
            // 3. On blur (losing focus): Also remove the dropdown.
            // This now works because we removed the conflicting "click-away" listener.
            select.addEventListener('blur', () => {
                 if (select.parentNode) {
                    select.parentNode.removeChild(select);
                }
            });
            // Add to page and give it focus to see the options immediately
            document.body.appendChild(select);
            select.focus();
        });
    }
    
    /**
     * A new method to run the analysis on all tables at once.
     */
    updateAllAnalyses() {
        this.analyzedTables.forEach(tableData => {
            this.updateTableAnalysis(tableData);
        });
    }

    // No changes are needed for evaluateCondition
    evaluateCondition(cellValue, operator, ruleValue) {
        if (ruleValue === "" || ruleValue === null || cellValue === undefined || cellValue === '') return false;
        const numCellValue = parseFloat(cellValue);
        const numRuleValue = parseFloat(ruleValue);
        switch (operator) {
            case '<': return numCellValue < numRuleValue;
            case '>': return numCellValue > numRuleValue;
            case '<=': return numCellValue <= numRuleValue;
            case '>=': return numCellValue >= numRuleValue;
            case '=': return cellValue.toString().toUpperCase() === ruleValue.toString().toUpperCase();
            default: return false;
        }
    }

    getAssetColorAndReasons(asset, rowData) {
        const redReasons = [];
        const yellowReasons = [];
        const wx = rowData['WX'] || '';
        if (wx && asset.presentWeather) {
            for (const rule of asset.presentWeather) {
                if (wx.toUpperCase().includes(rule.code.toUpperCase())) {
                    const reason = rule.reason || `Present weather contains: ${rule.code}`;
                    if (rule.color === 'Red') redReasons.push(reason);
                    if (rule.color === 'Yellow') yellowReasons.push(reason);
                }
            }
        }
        if (asset.thresholds) {
            for (const rule of asset.thresholds) {
                const cellValue = rowData[rule.parameter];
                if (this.evaluateCondition(cellValue, rule.operator, rule.value)) {
                    const reason = rule.reason || `${rule.parameter} ${rule.operator} ${rule.value} (is ${cellValue})`;
                    if (rule.color === 'Red') redReasons.push(reason);
                    if (rule.color === 'Yellow') yellowReasons.push(reason);
                }
            }
        }
        let color = 'Green';
        if (redReasons.length > 0) {
            color = 'Red';
        } else if (yellowReasons.length > 0) {
            color = 'Yellow';
        }
        return { color, redReasons, yellowReasons };
    }

    /**
     * This method is now updated to analyze a specific table's data.
     * @param {object} tableData - The object containing the table's element, body, and headerMap.
     */
    updateTableAnalysis(tableData) {
        tableData.body.querySelectorAll('tr').forEach(row => {
            const cells = row.querySelectorAll('td');
            const rowData = {};
            for (const headerName in tableData.headerMap) {
                if (cells[tableData.headerMap[headerName]]) {
                    rowData[headerName] = cells[tableData.headerMap[headerName]].textContent.trim();
                }
            }
            const tempoText = rowData['TEMPO CONDITIONS/HAZARDS (AGL)'];
            rowData['LLWS'] = '';
            rowData['ICG'] = '';
            rowData['TURB'] = '';
            if (tempoText) {
                const tempoUpper = tempoText.toUpperCase();
                const llwsMatch = tempoUpper.match(/LLWS\s*(\d+)/);
                if (llwsMatch) rowData['LLWS'] = llwsMatch[1];
                const icgMatch = tempoUpper.match(/(LGT|MDT|SEV|SVR)\s*ICG/);
                if (icgMatch) rowData['ICG'] = icgMatch[1].replace('SVR', 'SEV');
                const turbMatch = tempoUpper.match(/(LGT|MDT|SEV|SVR)\s*TURB/);
                if (turbMatch) rowData['TURB'] = turbMatch[1].replace('SVR', 'SEV');
            }
            const rawWinds = rowData['WINDS'];
            if (rawWinds) {
                let windValue = '';
                const gustMatch = rawWinds.match(/G(\d{2,3})KT/);
                if (gustMatch && gustMatch[1]) {
                    windValue = gustMatch[1];
                } else {
                    const speedMatch = rawWinds.match(/(?:\d{3}|VRB)(\d{2,3})KT/);
                    if (speedMatch && speedMatch[1]) {
                        windValue = speedMatch[1];
                    }
                }
                if (windValue) {
                    rowData['WINDS'] = windValue;
                }
            }
            
            this.config.assets.forEach(asset => {
                const result = this.getAssetColorAndReasons(asset, rowData);
                const assetCell = row.querySelector(`td[data-asset-name="${asset.name}"]`);
                if (assetCell) {
                    assetCell.classList.remove('Red', 'Yellow', 'Green');
                    assetCell.classList.add(result.color);

                    let tooltipParts = [];
                    if (result.redReasons.length > 0) {
                        tooltipParts.push('Red Impacts:\n- ' + result.redReasons.join('\n- '));
                    }
                    if (result.yellowReasons.length > 0) {
                        tooltipParts.push('Yellow Impacts:\n- ' + result.yellowReasons.join('\n- '));
                    }
                    if (tooltipParts.length > 0) {
                        assetCell.title = tooltipParts.join('\n\n');
                    } else {
                        assetCell.title = 'Conditions are favorable.';
                    }
                }
            });
        });
    }
}
