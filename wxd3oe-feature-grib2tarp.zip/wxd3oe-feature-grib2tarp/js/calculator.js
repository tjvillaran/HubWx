// =============================================================================
// calculator.js  —  Date/time helpers and unit conversions for the MEF tool
// =============================================================================

/**
 * Returns a UTC Date set to the next upcoming hour in the given list.
 * @param {number[]} times  Array of UTC hours, e.g. [0, 8, 16]
 * @returns {Date}
 */
function findNextHourInList(times) {
    const now   = new Date();
    const nowH  = now.getUTCHours();
    const nowM  = now.getUTCMinutes();
    const sorted = [...times].map(Number).sort((a, b) => a - b);

    // First upcoming hour today (strictly after current time)
    for (const h of sorted) {
        if (h > nowH || (h === nowH && nowM === 0)) {
            return new Date(Date.UTC(
                now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(), h, 0, 0
            ));
        }
    }

    // Wrap to next day
    return new Date(Date.UTC(
        now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + 1, sorted[0], 0, 0
    ));
}

/**
 * Returns the next issue-time label used in the MEF header, e.g. "30A".
 * Format: DD + letter (A = 1st issue of the day, B = 2nd, …)
 * This function just returns "DDA" — the version letter is managed by
 * mef_tool.html's version counter.
 * @param {number[]} times
 * @returns {string}
 */
function getFormattedNextHourString(times) {
    const next = findNextHourInList(times);
    const day  = String(next.getUTCDate()).padStart(2, '0');
    return day + 'A';
}

/**
 * Format a Date as "YYYYMMDD/HHZ" (MEF issue / valid time field).
 * @param {Date} date
 * @returns {string}
 */
function formatDateToUTC_YYYYMMDDHHZ(date) {
    const Y  = date.getUTCFullYear();
    const Mo = String(date.getUTCMonth() + 1).padStart(2, '0');
    const D  = String(date.getUTCDate()).padStart(2, '0');
    const H  = String(date.getUTCHours()).padStart(2, '0');
    return `${Y}${Mo}${D}/${H}Z`;
}

/**
 * Format a Date as "DD/HHZ" (TOLD row time stamp).
 * @param {Date} date
 * @returns {string}
 */
function formatDateToUTC_dd_HHZ(date) {
    const D = String(date.getUTCDate()).padStart(2, '0');
    const H = String(date.getUTCHours()).padStart(2, '0');
    return `${D}/${H}Z`;
}

/**
 * Return a new Date with `n` whole hours added.
 * @param {Date}   date
 * @param {number} n
 * @returns {Date}
 */
function addHours(date, n) {
    return new Date(date.getTime() + n * 3_600_000);
}

/**
 * Whole-hour difference: date1 − date2, rounded.
 * @param {Date} date1
 * @param {Date} date2
 * @returns {number}
 */
function hourDiff(date1, date2) {
    return Math.round((date1 - date2) / 3_600_000);
}

/**
 * Convert metres to feet (rounded to nearest foot).
 * @param {number} m
 * @returns {number}
 */
function metersToFeet(m) {
    return Math.round(m * 3.28084);
}

/**
 * Convert a model temperature (Kelvin) to Celsius and Fahrenheit.
 * @param {number} kelvin
 * @returns {{ K: number, C: number, F: number }}
 */
function temperature(kelvin) {
    const C = Math.round(kelvin - 273.15);
    const F = Math.round(C * 9 / 5 + 32);
    return { K: kelvin, C, F };
}
