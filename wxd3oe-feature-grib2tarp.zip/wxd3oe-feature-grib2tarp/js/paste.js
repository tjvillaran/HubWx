class PasteHandler {
  constructor(containerElement, suffix) {
    this.container = containerElement;
    if (!this.container) {
      throw new Error(`PasteHandler: A valid container element was not provided.`);
    }

    this.targetElement        = this.container.querySelector(`#paste-target-${suffix}`);
    this.imageContainer       = this.container.querySelector(`#image-container-${suffix}`);
    this.gridControlsContainer = this.container.querySelector('.grid-controls');
    this.gridControls         = this.container.querySelectorAll(`input[name="grid-size-${suffix}"]`);
    this.images = [];
    this._draggingWrapper = null;

    if (!this.targetElement || !this.imageContainer || !this.gridControlsContainer) {
      throw new Error(`PasteHandler: missing child elements for suffix "${suffix}".`);
    }

    // Wire the title-bar paste target and any ghost slots already in the DOM
    this._wireTarget(this.targetElement);
    this._wireAllGhostSlots();

    // Re-attach drag listeners to any wrappers already filled (e.g. from loaded JSON)
    this._rewireExistingFilledWrappers();

    // Grid controls
    this.gridControls.forEach(radio =>
      radio.addEventListener('change', (e) => this.setGridColumns(e.target.value))
    );

    // Image-container click delegation (delete / resize buttons)
    this.imageContainer.addEventListener('click',    this._onContainerClick.bind(this));
    this.imageContainer.addEventListener('dblclick', this._onContainerDblClick.bind(this));

    // Internal-reorder drag on the container (only fires for wrappers we started)
    this.container.addEventListener('dragover', (e) => {
      if (!this._draggingWrapper) return;
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      const target = this._getDropTarget(e);
      this._clearDropIndicators();
      if (target) target.wrapper.classList.add(target.before ? 'drag-insert-before' : 'drag-insert-after');
    });

    this.container.addEventListener('drop', (e) => {
      if (!this._draggingWrapper) return;
      e.preventDefault();
      this._clearDropIndicators();
      const target = this._getDropTarget(e);
      if (target) {
        this.imageContainer.insertBefore(
          this._draggingWrapper,
          target.before ? target.wrapper : target.wrapper.nextSibling
        );
        this.images = [...this.imageContainer.querySelectorAll('.image-wrapper.filled')];
      }
    });

    this.updateGridControlsVisibility();
  }

  // ── Title-bar paste target ──────────────────────────────────────────────────
  // The original contenteditable header cell. Paste here → fill next ghost slot.
  _wireTarget(el) {
    el.addEventListener('paste', (e) => {
      const items = (e.clipboardData || e.originalEvent?.clipboardData)?.items;
      if (!items) return;
      for (const item of items) {
        if (item.type.startsWith('image/')) {
          e.preventDefault();
          this._readFile(item.getAsFile(), null);
          return;
        }
      }
    });
  }

  // ── Rewire existing filled wrappers (called after JSON restore) ──────────────
  // When mef_html is injected via innerHTML the DOM elements exist but have no
  // JS event listeners. Walk every filled wrapper and ghost slot and reattach
  // drag handles + push into this.images so reorder works immediately.
  _rewireExistingFilledWrappers() {
    this.imageContainer.querySelectorAll('.image-wrapper').forEach(wrapper => {
      if (!wrapper.classList.contains('filled')) return;  // unfilled ghosts handled by _wireGhostSlot
      if (wrapper.dataset.dragWired) return;              // already done (shouldn't happen, but safe)
      wrapper.dataset.dragWired = '1';

      // Ensure draggable is set — innerHTML may not have preserved it
      wrapper.draggable = true;

      wrapper.addEventListener('dragstart', (e) => this._onWrapperDragStart(e, wrapper));
      wrapper.addEventListener('dragend',   ()  => this._onWrapperDragEnd());

      this.images.push(wrapper);
    });

    this.updateGridControlsVisibility();
  }

  // ── Ghost slot wiring ───────────────────────────────────────────────────────
  // Call once at init, and again if new slots are added later.
  _wireAllGhostSlots() {
    this.imageContainer.querySelectorAll('.ghost-slot').forEach(slot => this._wireGhostSlot(slot));
  }

  _wireGhostSlot(slot) {
    if (slot.dataset.wired) return;
    slot.dataset.wired = '1';

    // contenteditable is the ONLY reliable cross-browser way to receive paste
    // events on a non-input element. We immediately preventDefault so no text
    // is ever inserted.
    slot.setAttribute('contenteditable', 'true');

    // Block all keyboard input so the slot never shows typed text
    slot.addEventListener('keydown', (e) => e.preventDefault());

    // ── Paste ───────────────────────────────────────────────────────────────
    slot.addEventListener('paste', (e) => {
      if (slot.classList.contains('filled')) return;
      const items = (e.clipboardData || e.originalEvent?.clipboardData)?.items;
      if (!items) return;
      for (const item of items) {
        if (item.type.startsWith('image/')) {
          e.preventDefault();
          e.stopPropagation();
          this._readFile(item.getAsFile(), slot);
          return;
        }
      }
    });

    // ── Drag and drop ───────────────────────────────────────────────────────
    slot.addEventListener('dragover', (e) => {
      if (this._draggingWrapper) return; // internal reorder — let container handle it
      if (slot.classList.contains('filled')) return;
      e.preventDefault();
      e.stopPropagation();
      e.dataTransfer.dropEffect = 'copy';
      slot.classList.add('drag-hover');
    });

    slot.addEventListener('dragleave', (e) => {
      if (!slot.contains(e.relatedTarget)) {
        slot.classList.remove('drag-hover');
      }
    });

    slot.addEventListener('drop', (e) => {
      if (this._draggingWrapper) return; // internal reorder — let container handle it
      if (slot.classList.contains('filled')) return;
      e.preventDefault();
      e.stopPropagation();
      slot.classList.remove('drag-hover');

      const files = e.dataTransfer.files;
      const html  = e.dataTransfer.getData('text/html');

      if (files.length > 0) {
        this._readFile(files[0], slot);
      } else if (html) {
        const doc = new DOMParser().parseFromString(html, 'text/html');
        const img = doc.querySelector('img');
        if (img?.src) {
          const src = new URL(img.src, document.baseURI).href;
          this.fillSlot(slot, src);
        }
      }
    });
  }

  // ── Fill a specific slot ────────────────────────────────────────────────────
  fillSlot(slot, src) {
    if (!slot || slot.classList.contains('filled')) return;

    // Stop accepting paste/drop by removing contenteditable
    slot.removeAttribute('contenteditable');

    slot.querySelector('.ghost-placeholder')?.remove();

    const img = document.createElement('img');
    img.src = src;

    const deleteButton = document.createElement('button');
    deleteButton.className = 'delete-button';
    deleteButton.innerHTML = '&times;';

    const resizeButton = document.createElement('button');
    resizeButton.className = 'resize-button';
    resizeButton.innerHTML = '&#x2194;';

    const label = slot.querySelector('.image-text');
    if (label) label.insertAdjacentElement('afterend', img);
    else        slot.insertBefore(img, slot.firstChild);

    slot.appendChild(deleteButton);
    slot.appendChild(resizeButton);

    slot.classList.add('filled');
    slot.draggable = true;
    slot.dataset.dragWired = '1';
    slot.addEventListener('dragstart', (e) => this._onWrapperDragStart(e, slot));
    slot.addEventListener('dragend',   ()  => this._onWrapperDragEnd());

    this.images.push(slot);
    this.updateGridControlsVisibility();
  }

  // ── addImage: fills next ghost slot, or appends a new wrapper ──────────────
  addImage(src) {
    const ghost = this.imageContainer.querySelector('.ghost-slot:not(.filled)');
    if (ghost) {
      this.fillSlot(ghost, src);
      return;
    }

    // No ghost slots — create a plain wrapper
    const wrapper = document.createElement('div');
    wrapper.className = 'image-wrapper';
    wrapper.draggable = true;
    wrapper.dataset.dragWired = '1';
    wrapper.addEventListener('dragstart', (e) => this._onWrapperDragStart(e, wrapper));
    wrapper.addEventListener('dragend',   ()  => this._onWrapperDragEnd());

    const img          = document.createElement('img');    img.src = src;
    const deleteButton = document.createElement('button'); deleteButton.className = 'delete-button'; deleteButton.innerHTML = '&times;';
    const resizeButton = document.createElement('button'); resizeButton.className = 'resize-button'; resizeButton.innerHTML = '&#x2194;';

    wrapper.append(img, deleteButton, resizeButton);
    this.imageContainer.appendChild(wrapper);
    this.images.push(wrapper);
    this.updateGridControlsVisibility();
  }

  // ── removeImage ─────────────────────────────────────────────────────────────
  removeImage(wrapper) {
    if (!wrapper) return;

    if (wrapper.classList.contains('ghost-slot')) {
      // Restore ghost slot to empty — re-enable paste/drop
      wrapper.querySelector('img')?.remove();
      wrapper.querySelector('.delete-button')?.remove();
      wrapper.querySelector('.resize-button')?.remove();

      const ph = document.createElement('div');
      ph.className = 'ghost-placeholder';
      ph.textContent = 'Drop or paste image here';
      wrapper.appendChild(ph);

      wrapper.classList.remove('filled');
      wrapper.draggable = false;
      delete wrapper.dataset.dragWired;
      wrapper.setAttribute('contenteditable', 'true');

      const idx = this.images.indexOf(wrapper);
      if (idx > -1) this.images.splice(idx, 1);
    } else {
      this.imageContainer.removeChild(wrapper);
      const idx = this.images.indexOf(wrapper);
      if (idx > -1) this.images.splice(idx, 1);
    }

    this.updateGridControlsVisibility();
  }

  // ── Grid columns ─────────────────────────────────────────────────────────────
  setGridColumns(columns) {
    this.imageContainer.className = 'image-container';
    this.imageContainer.classList.add(`grid-cols-${columns}`);
  }

  updateGridControlsVisibility() {
    this.gridControlsContainer.classList.toggle('hidden', this.images.length === 0);
  }

  // ── Image container delegation ────────────────────────────────────────────────
  _onContainerClick(e) {
    const wrapper = e.target.closest('.image-wrapper');
    if (!wrapper) return;
    if (e.target.classList.contains('delete-button'))  { this.removeImage(wrapper); return; }
    if (e.target.classList.contains('resize-button'))  { wrapper.classList.toggle('size-to-fit'); }
  }

  _onContainerDblClick(e) {
    if (e.target.tagName !== 'IMG') return;
    const wrapper = e.target.closest('.image-wrapper');
    if (!wrapper) return;
    const existing = wrapper.querySelector('.image-text');
    const current  = existing ? existing.textContent : '';
    const next     = prompt('Enter a label for this image:', current);
    if (next === null) return;
    if (!next.trim()) { existing?.remove(); return; }
    if (existing) existing.textContent = next;
    else {
      const el = document.createElement('div');
      el.className = 'image-text';
      el.textContent = next;
      wrapper.insertBefore(el, wrapper.firstChild);
    }
  }

  // ── Internal reorder helpers ───────────────────────────────────────────────
  _onWrapperDragStart(e, wrapper) {
    this._draggingWrapper = wrapper;
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', 'internal-reorder');
    requestAnimationFrame(() => wrapper.classList.add('dragging'));
  }

  _onWrapperDragEnd() {
    if (this._draggingWrapper) {
      this._draggingWrapper.classList.remove('dragging');
      this._draggingWrapper = null;
    }
    this._clearDropIndicators();
  }

  _clearDropIndicators() {
    this.imageContainer.querySelectorAll('.drag-insert-before, .drag-insert-after').forEach(el => {
      el.classList.remove('drag-insert-before', 'drag-insert-after');
    });
  }

  _getDropTarget(e) {
    for (const w of this.imageContainer.querySelectorAll('.image-wrapper')) {
      if (w === this._draggingWrapper) continue;
      const r = w.getBoundingClientRect();
      if (e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom) {
        return { wrapper: w, before: e.clientX < r.left + r.width / 2 };
      }
    }
    return null;
  }

  _readFile(file, slot) {
    if (!file?.type.startsWith('image/')) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      if (slot) this.fillSlot(slot, e.target.result);
      else      this.addImage(e.target.result);
    };
    reader.readAsDataURL(file);
  }
}
