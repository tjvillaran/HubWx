// =================================================================================
// ORIGINAL FLIMSY CLASS AND HELPER FUNCTIONS (CLEANED UP)
// =================================================================================

class Flimsy {

    constructor(objTarpFiles, objConfig, objAssetConfig) {
        this.listTarpFiles = objTarpFiles;
        this.mefConfig = objConfig;
        this.assetConfig = objAssetConfig;
        this.listOfTimes = this.mefConfig.siteConfig["validTimes"].split(",");
        this.mefDate = findNextHourInList(this.listOfTimes);
        this.interval = parseInt(this.mefConfig.siteConfig["interval"]);
        this.duration = parseInt(this.mefConfig.siteConfig["duration"]);
    }

    createClassificationBlock() {
        const configurationFile = this.mefConfig.siteConfig;
        const classification = configurationFile.classification || 'Unclassified CUI';
        let bannerColor = '#90EE90'; // Green for UNCLASSIFIED
        if (classification.toUpperCase().includes('SECRET')) {
            bannerColor = '#FF0000'; // Red for SECRET
        }
        return `
        <table id="table_security" class="table security savable-table">
            <tr>
                <th colspan="10" class="sec" style="background-color: ${bannerColor};">
                    ${classification}
                </th>
            </tr>
        </table>`;
    }

    createHeaderBlock() {
        const configurationFile = this.mefConfig.siteConfig;
        return `
        <table id="table_header" class="table header savable-table">
            <tr><th colspan="10" class="hd" contenteditable="true">${configurationFile.title || ''}</th></tr>
            <tr><th colspan="10" class="hd">${configurationFile.disclaimer || ''}</th></tr>
            <tr><td colspan="10">${configurationFile.contact_info + "<br>" + configurationFile.PMSV || ''}</td></tr>
            <tr>
                <td colspan="2">ISSUE TIME</td><td colspan="2">VALID TIME</td><td colspan="2">FORECASTER</td>
                <td colspan="2">FORECASTER PHONE</td><td colspan="2">FLIMSY #</td>
            </tr>
            <tr>
                <td colspan="2" contenteditable="true">${formatDateToUTC_YYYYMMDDHHZ(this.mefDate)}</td>
                <td colspan="2" contenteditable="true">${formatDateToUTC_YYYYMMDDHHZ(this.mefDate)}</td>
                <td colspan="2" contenteditable="true"></td>
                <td colspan="2" contenteditable="true">${configurationFile.forecaster_phone || ''}</td>
                <td colspan="2" contenteditable="true">${getFormattedNextHourString(this.listOfTimes)}</td>
            </tr>
            <tr>
                <td colspan="2">BRIEF TIME</td><td colspan="2">VOID TIME</td><td colspan="2">BRIEFER'S INITIALS</td>
                <td colspan="2">SDO'S INITIALS</td><td colspan="2">PILOT'S INITIALS</td>
            </tr>
            <tr>
                <td colspan="2" contenteditable="true"></td><td colspan="2" contenteditable="true"></td>
                <td colspan="2" contenteditable="true"></td><td colspan="2" contenteditable="true"></td>
                <td colspan="2" contenteditable="true"></td>
            </tr>
        </table>`;
    }

    createSynopticSection() {
        // MODIFIED: Added 'savable-element' class and 'data-save-key' for JSON export
        return `
        <table id="table_synoptic" class="table synoptic">
            <tr><th class="hd" colspan="10">Synoptic Discussion</th></tr>
            <tr><td contenteditable="true" word-wrap="break-word" colspan="10" class="discussion savable-element" data-save-key="discussion.synoptic"></td></tr>
        </table>`;
    }

    createPasteable(pasteObj, legendSrc) {
        // pasteObj: { name, count, interval, offset }
        // legendSrc: optional base64 data URI for a legend image shown below the drop zone
        // Backward compat: if a plain string is passed, treat as name-only
        if (typeof pasteObj === 'string') pasteObj = { name: pasteObj, count: 1, interval: 3, offset: 0 };
        const { name: label, count, interval, offset } = pasteObj;

        // Sanitize the label into a valid HTML id/CSS-selector-safe key.
        // Spaces and special characters are replaced with hyphens.
        const id = label.replace(/[^a-zA-Z0-9_-]/g, '-');

        // Pick best default grid column count
        const cols = count >= 4 ? 4 : count === 3 ? 3 : count === 2 ? 2 : 1;

        // Build grid-controls radio buttons including 3 if count >= 3
        const hasThree = count >= 3;
        const gridControls = `
            <div class="grid-controls hidden">
                <span>Grid Layout:</span>
                <label><input type="radio" name="grid-size-${id}" value="1" ${cols===1?'checked':''}> 1</label>
                <label><input type="radio" name="grid-size-${id}" value="2" ${cols===2?'checked':''}> 2</label>
                ${hasThree ? `<label><input type="radio" name="grid-size-${id}" value="3" ${cols===3?'checked':''}> 3</label>` : ''}
                <label><input type="radio" name="grid-size-${id}" value="4" ${cols===4?'checked':''}> 4</label>
            </div>`;

        // Pre-render ghost slot wrappers with time labels
        // Snap the start time back to the nearest interval boundary so that
        // e.g. a 08Z issue with interval=3 starts at 06Z (not 08Z).
        const snapHours = this.mefDate.getUTCHours() % interval;
        const snapBase  = addHours(this.mefDate, -snapHours);
        let ghostSlots = '';
        for (let i = 0; i < count; i++) {
            const slotDate  = addHours(snapBase, offset + i * interval);
            const timeLabel = formatDateToUTC_dd_HHZ(slotDate);
            ghostSlots += `
            <div class="image-wrapper ghost-slot" data-slot-index="${i}" draggable="false">
                <div class="image-text">${timeLabel}</div>
                <div class="ghost-placeholder">Drop or paste image here</div>
            </div>`;
        }

        const legendBlock = legendSrc
            ? `<div class="pasteable-legend-wrap"><img src="${legendSrc}" alt="${label} legend"></div>`
            : '';

        return `
        <div class="pasteable-container" data-suffix="${id}">
            <table class="table pasteable">
                <tr><td class="hd" id="paste-target-${id}" contenteditable="true" colspan="10">${label} — Paste Images Here</td></tr>
            </table>
            ${gridControls}
            <div id="image-container-${id}" class="image-container grid-cols-${cols}">${ghostSlots}</div>
            ${legendBlock}
        </div>`;
    }

    createCommentSection() {
        // MODIFIED: Added 'savable-element' class and 'data-save-key' for JSON export
        return `
        <table id="table_comment" class="table synoptic">
            <tr><th class="hd" colspan="10">Comments</th></tr>
            <tr><td contenteditable="true" word-wrap="break-word" colspan="10" class="discussion savable-element" data-save-key="discussion.comments">${this.mefConfig.siteConfig.comments}</td></tr>
        </table>`;
    }

    createTOLD(icao) {
        const tarpData = findKeyInJsonList(this.listTarpFiles, icao);
        let tableHTML = "";
        if (tarpData == false) {
            tableHTML = `
            <table id="table_told_${icao}" class="table told savable-table">
                <thead>
                    <tr><th colspan="10" contenteditable="true" class="hd"><font color="red">//Location Name// (${icao}) TAKE OFF AND LANDING DATA ELEV //Elev// FT</font></th></tr>
                    <tr>
                        <th class="titles">ZULU</th><th class="titles">WINDS</th><th class="titles">VIS</th><th class="titles">WX</th><th class="titles">CIG</th>
                        <th class="titles">TEMP</th><th class="titles">ALSTG</th><th class="titles">PA</th><th class="titles">DA</th><th class="titles">TEMPO CONDITIONS/HAZARDS (AGL)</th>
                    </tr>  
                </thead>
                <tbody>`;
            for (let i = 0; i <= this.duration; i += this.interval) {
                const toldStartDate = this.mefDate;
                tableHTML += `
                <tr>                  
                    <td contenteditable="true">${formatDateToUTC_dd_HHZ(addHours(toldStartDate, i))}</td>
                    <td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td>
                    <td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td>
                </tr>`;
            }
            tableHTML += `</tbody></table>`;
        } else {
            const elevation = metersToFeet(tarpData[icao].metadata.elevation);
            const modelDate = new Date(tarpData[icao].metadata.model_run);
            const modelOffset = hourDiff(this.mefDate, modelDate);
            let assets = (this.assetConfig.config != null && this.mefConfig.siteConfig.assets != null) ? this.mefConfig.siteConfig.assets.split(",") : [];
            
            tableHTML = `<table id="table_told_${icao}" class="table told savable-table"><thead><tr>
                <th colspan="10" class="elevation hd">${tarpData[icao].metadata.name} (${icao}) TAKE OFF AND LANDING DATA ELEV ${elevation} FT</th>`;
            if (assets.length > 0) {
                tableHTML += `<th colspan="${assets.length}" class="hd">Impacts</th>`;
            }
            tableHTML += `</tr><tr>
                <th class="titles">ZULU</th><th class="titles">WINDS</th><th class="titles">VIS</th><th class="titles">WX</th><th class="titles">CIG</th>
                <th class="titles">TEMP</th><th class="titles">ALSTG</th><th class="titles">PA</th><th class="titles">DA</th><th class="titles">TEMPO CONDITIONS/HAZARDS (AGL)</th>`;
            if (assets.length > 0) {
                assets.forEach(asset => tableHTML += `<th class="titles told-asset">${asset}</th>`);
            }
            tableHTML += `</tr></thead><tbody>`;

            for (let i = 0; i <= this.duration; i += this.interval) {
                const toldStartDate = this.mefDate;
                let temp = temperature(findValueOfHourOfParameter(tarpData[icao].timeseries, "2m_agl_tmp", modelOffset + i));
                let windDir = Math.round(parseInt(findValueOfHourOfParameter(tarpData[icao].timeseries, "10m_agl_dir", modelOffset + i)) / 10) * 10;
                let windSpd = Math.round(parseInt(findValueOfHourOfParameter(tarpData[icao].timeseries, "10m_agl_spd", modelOffset + i)) / 5) * 5;
                let winds = padNumber(windDir, 3) + padNumber(windSpd, 2) + "KT";
                let lowestCig = findValueOfHourOfParameter(tarpData[icao].timeseries, "lowest_cig", modelOffset + i).toFixed(0);
                let vis = findValueOfHourOfParameter(tarpData[icao].timeseries, "visibility", modelOffset + i).toFixed(0);
                vis = (this.mefConfig.siteConfig.visibility_units == "m") ? metricVisibility(vis) : vis + "SM";
                lowestCig = (lowestCig == 9999) ? "No Cig" : String(lowestCig).padStart(3, '0');
                
                tableHTML += `
                <tr>                  
                    <td contenteditable="true">${formatDateToUTC_dd_HHZ(addHours(toldStartDate, i))}</td><td contenteditable="true">${winds}</td>
                    <td contenteditable="true">${vis}</td><td contenteditable="true"></td><td contenteditable="true">${lowestCig}</td>
                    <td contenteditable="true">${temp.C} C</td><td contenteditable="true">${findValueOfHourOfParameter(tarpData[icao].timeseries, "altimeter", modelOffset + i).toFixed(2)}</td>
                    <td contenteditable="true">${addPlusSign(findValueOfHourOfParameter(tarpData[icao].timeseries, "press_alt", modelOffset + i).toFixed(0))}</td>
                    <td contenteditable="true">${addPlusSign(findValueOfHourOfParameter(tarpData[icao].timeseries, "density_alt", modelOffset + i).toFixed(0))}</td>
                    <td contenteditable="true"></td>`;
                if (assets.length > 0) {
                    assets.forEach(asset => tableHTML += `<td contenteditable="true" data-asset-name="${asset}"></td>`);
                }
                tableHTML += `</tr>`;
            }
            tableHTML += `</tbody></table>`;
        }
        return tableHTML;
    }

    createSectorTable(stationName, icao, display) {
        const tarpData = findKeyInJsonList(this.listTarpFiles, icao);
        const toldStartDate = this.mefDate;
        let tableHTML = "";

        if (tarpData == false) {
            tableHTML = `
            <table id="table_sector_${icao}" class="table sector savable-table">
               <tr>
                <th class="hd" colspan="1">${stationName || '//station_name//'}</th><th class="hd" colspan="1">Freezing Level:</th>
                <td class="sc" colspan="4" contenteditable="true" placeholder="">00000FT</td><th class="hd" style="border: none;" colspan="5"></th>
               </tr> 
               <tr>
                <th class="titles">TIME</th><th class="titles" colspan="6">VIS/WX/SKY COND (BASE/TOP - MSL)</th>
                <th class="titles" colspan="3">HAZARDS</th><th class="titles" colspan="1">ALSTG</th>
               </tr>`;
            for (let i = 0; i <= this.duration; i += this.interval) {
                tableHTML += `
               <tr>
                <td>${formatDateToUTC_dd_HHZ(addHours(toldStartDate, i))}</td><td colspan="6" contenteditable="true"></td>
                <td colspan="3" contenteditable="true"></td><td contenteditable="true"></td>
               </tr>`;
            }
            tableHTML += `</table>`;
            tableHTML += this.createWindTables(undefined, undefined, icao);
        } else {
            const modelDate = new Date(tarpData[icao].metadata.model_run);
            const modelOffset = hourDiff(this.mefDate, modelDate);
            let freezingLevel = 99999;
            for (let i = 0; i < this.duration; i++) {
                let tempLevel = findValueOfHourOfParameter(tarpData[icao].timeseries, "0c_height", modelOffset + i);
                if (tempLevel < freezingLevel) {
                    freezingLevel = tempLevel;
                }
            }
            tableHTML = `
            <table id="table_sector_${icao}" class="table sector savable-table">
               <tr>
                <th class="hd" colspan="1">${stationName}</th><th class="hd" colspan="1">Freezing Level:</th>
                <td class="sc" colspan="4" contenteditable="true" placeholder="00000FT"> ${metersToFeet(freezingLevel.toFixed(0))}FT</td>
                <th class="hd" style="border: none;" colspan="5"></th>
               </tr> 
               <tr>
                <th class="titles">TIME</th><th class="titles" colspan="6">VIS/WX/SKY COND (BASE/TOP - MSL)</th>
                <th class="titles" colspan="3">HAZARDS</th><th class="titles" colspan="1">ALSTG</th>
               </tr>`;
            for (let i = 0; i <= this.duration; i += this.interval) {
                tableHTML += `
               <tr>
                <td>${formatDateToUTC_dd_HHZ(addHours(toldStartDate, i))}</td><td colspan="6" contenteditable="true"></td>
                <td colspan="3" contenteditable="true"></td><td contenteditable="true">${findValueOfHourOfParameter(tarpData[icao].timeseries, "altimeter", modelOffset + i).toFixed(2)}</td>
               </tr>`;
            }
            tableHTML += `</table>`;

            if (display == "both" || typeof display === 'undefined') {
                tableHTML += this.createWindTables(tarpData[icao].timeseries, modelOffset, icao);
            } else if (display == "flwinds") {
                return this.createWindTables(tarpData[icao].timeseries, modelOffset, icao);
            }
        }
        return tableHTML;
    }

    createWindTables(timeseries, offset, icao) {
        let segments = Math.ceil(this.duration / 4);
        const toldStartDate = this.mefDate;
        timeseries = (typeof timeseries !== 'undefined') ? timeseries : "";
        offset = (typeof offset !== 'undefined') ? offset : "";
        let hours = 0;
        let tableHTML = `<table class="table"><tr>`;
        for (let i = 0; i < 4; i++) {
            tableHTML += `<td>
                <table id="table_winds_${icao}_${i}" class="table flwinds savable-table">
                    <tr><th colspan="2" class="hd">Valid: ${formatDateToUTC_dd_HHZ(addHours(toldStartDate, hours))}</th></tr>
                    <tr><th class="titles">FL LVL</th><th class="titles">WINDS/TEMP</th></tr>`;
            const flevels = this.mefConfig.siteConfig.flightlevels.split(",");
            for (let j = 0; j < flevels.length; j++) {
                tableHTML += `
                <tr>
                    <td>${flevels[j] || ''}</td>
                    <td contenteditable="true">${flWindsTemp(timeseries, flevels[j], (offset || 0) + hours).display || ''}</td>           
                </tr>`;
            }
            tableHTML += `</table></td>`;
            hours += segments;
        }
        tableHTML += `</tr></table>`;
        return tableHTML;
    }

    createSolarLunar(icao, days = 1) {
        const tarpData = findKeyInJsonList(this.listTarpFiles, icao);
        if (!tarpData) {
            alert("Lat and Long Data not available");
            return "";
        }
        let tableHTML = `
        <table id="table_solar_lunar_${icao}" class="table solar_lunar savable-table">
            <tr><th class="hd" colspan="16">SOLAR / LUNAR DATA FOR ${icao}</th></tr>`;
        for (let i = 0; i < days; i++) {
            let solarDate = new Date(this.mefDate);
            solarDate.setUTCDate(solarDate.getUTCDate() + i);
            let solarYear = solarDate.getUTCFullYear();
            let solarMonth = solarDate.getUTCMonth() + 1;
            let solarDay = solarDate.getUTCDate();
            let lat = tarpData[icao].metadata.latitude;
            let long = tarpData[icao].metadata.longitude;
            let solarInfo = mefCalc(solarYear, solarMonth, solarDay, lat, long, 0);
            tableHTML += `
            <tr>
                <td>DATE:</td><td>${solarInfo[0]}</td><td>BMNT:</td><td>${solarInfo[6]}Z</td>
                <td>Sunrise:</td><td>${solarInfo[2]}Z</td><td>Sunset:</td><td>${solarInfo[3]}Z</td>
                <td>EENT:</td><td>${solarInfo[7]}Z</td><td>MR:</td><td>${solarInfo[11]}Z</td> 
                <td>MS:</td><td>${solarInfo[12]}Z</td><td>ILLUM:</td><td>${solarInfo[13]}</td>
            </tr>`;
        }
        tableHTML += `</table>`;
        return tableHTML;
    }

    createSpaceWxTable(){
	let tableHTML = `

                <table id="table_space" class="table space_weather savable-table">
                    <tr>
                    <th class="hd">Space WX</th>
                    <th class="titles">GPS:</th>
                    <td onClick="addSelect(this.id);" id="gps"><select onChange="colorChange(this.id,this.value);" id="gps">
                                                <option value="White">Select</option>
                                                <option value="Green">Favorable</option>
                                                <option value="Yellow">Marginal</option>
                                                <option value="Red">Unfavorable</option>
						<option value="Grey">Unavailable</option>
                                                </select></td>
                    <th class="titles">HF:</th>
                    <td onClick="addSelect(this.id);" id="hf"><select onChange="colorChange(this.id,this.value);" id="hf">
						<option value="White">Select</option>
                                                <option value="Green">Favorable</option>
                                                <option value="Yellow">Marginal</option>
                                                <option value="Red">Unfavorable</option>
						<option value="Grey">Unavailable</option>
                                                </select></td>
                    <th class="titles">UHF:</th>
                    <td onClick="addSelect(this.id);" id="uhf"><select onChange="colorChange(this.id,this.value);" id="uhf">
                                                <option value="White">Select</option>
                                                <option value="Green">Favorable</option>
                                                <option value="Yellow">Marginal</option>
                                                <option value="Red">Unfavorable</option>
						<option value="Grey">Unavailable</option>
                                                </select></td>
                    <th class="hd">Contrails</th>
                    <th class="titles">Bases:</th>
                    <td contenteditable="true">000</td>
                    <th class="titles">Tops:</th>
                    <td contenteditable="true">000</td>
                    </tr>
             
                </table> `

	return tableHTML;
	}

    createTAFSection() {
        let tafs = this.mefConfig.siteConfig.TAFS.split(",");
        let tableHTML = `<table id="table_tafs" class="table tafs savable-table">
            <tr><th class="hd" colspan="10">Local TAFs</th></tr>`;
        for (let i = 0; i < tafs.length; i += 2) {
            const icao0 = (tafs[i]     || '').trim();
            const icao1 = (tafs[i + 1] || '').trim();
            tableHTML += `
            <tr>
                <td class="TAF" contenteditable="true" colspan="5" data-icao="${icao0}">${icao0}</td>
                <td class="TAF" contenteditable="true" colspan="5" data-icao="${icao1}">${icao1}</td>
            </tr>`;
        }
        tableHTML += `</table>`;
        return tableHTML;
    }

    cleanTAF(text) {
        if (!text) return '';
        let clean = text.replace(/[\s\u00A0]+/g, ' ').trim();
        clean = clean.replace(/ (FM\d|TEMPO|BECMG|PROB\d\d)/g, '\n$1');
        return clean;
    }

    initializeTAFListeners() {
        // Wiring is now handled by rewireTAFPasteHandlers() in mef_tool.html
        // (called via rewirePasteHandlers on both generate and restore paths).
    }

    _extractTAFIcao(text) {
        const skip = new Set(['TAF', 'AMD', 'COR', 'NIL']);
        for (const word of text.trim().split(/\s+/)) {
            if (/^[A-Z]{4}$/.test(word) && !skip.has(word)) return word;
        }
        return null;
    }

    generateMEFTables() {
        let mefTable = this.createClassificationBlock();
        mefTable += this.createHeaderBlock();
        if (this.mefConfig.siteConfig.synoptic != "false") {
            mefTable += this.createSynopticSection();
        }
        mefTable += this.createCommentSection();

        const tolds = this.mefConfig.siteConfig.TOLDS.split(",");
        for (let i = 0; i < tolds.length; i++) {
            if (tolds[i]) mefTable += this.createTOLD(tolds[i]);
        }
        
        const sectors = this.mefConfig.siteConfig.SECTORS;
        if(sectors) {
            for (let i = 0; i < sectors.length; i++) {
                if(sectors[i] && sectors[i].icao) mefTable += this.createSectorTable(sectors[i].display_name, sectors[i].icao, sectors[i].display);
            }
        }

        const solarIcaos = this.mefConfig.siteConfig.solarID.split(",");
        if (solarIcaos.length > 0 && solarIcaos[0]) {
            for (let i = 0; i < solarIcaos.length; i++) {
                if (this.mefConfig.siteConfig.solarDays && this.mefConfig.siteConfig.solarDays != "undefined") {
                    mefTable += this.createSolarLunar(solarIcaos[i], parseInt(this.mefConfig.siteConfig.solarDays));
                } else {
                    mefTable += this.createSolarLunar(solarIcaos[i]);
                }
            }
        }

        mefTable += this.createSpaceWxTable();
        mefTable += this.createTAFSection();

        if (this.mefConfig.siteConfig.pasteable && this.mefConfig.siteConfig.pasteable != "undefined") {
            const legends    = this.mefConfig.siteConfig.pasteableLegends || {};
            const pasteables = this.mefConfig.siteConfig.pasteable.split(",");
            for (let i = 0; i < pasteables.length; i++) {
                const raw = pasteables[i].trim();
                if (!raw) continue;
                const parts = raw.split(':');
                const pasteObj = {
                    name:     parts[0] || '',
                    count:    Math.max(1, parseInt(parts[1]) || 1),
                    interval: Math.max(1, parseInt(parts[2]) || 3),
                    offset:   Math.max(0, parseInt(parts[3]) || 0),
                };
                if (pasteObj.name) {
                    const legendSrc = legends[pasteObj.name] || null;
                    mefTable += this.createPasteable(pasteObj, legendSrc);
                }
            }
        }

        mefTable += this.createClassificationBlock();
        return mefTable;
    }

    // =================================================================================
    // NEW METHODS FOR JSON EXPORT
    // =================================================================================
    
    /**
     * Helper function to set a value in a nested object based on a string path.
     * @private
     */
    _set(obj, path, value) {
        const keys = path.split('.');
        const lastKey = keys.pop();
        const lastObj = keys.reduce((o, key) => o[key] = o[key] || {}, obj);
        lastObj[lastKey] = value;
    }

    /**
     * Iterates through all 'savable' items, extracts their data, and compiles it into a JSON object.
     */
    exportToJson() {
        const allData = {};

        // Process all tables marked with '.savable-table'
        document.querySelectorAll('.savable-table').forEach(table => {
            const tableId = table.id;
            if (!tableId) return;

            if (tableId.startsWith('table_told_')) {
                const icao = tableId.replace('table_told_', '');
                this._set(allData, `told.${icao}`, this.extractToldData(table));
            } else if (tableId.startsWith('table_sector_')) {
                const icao = tableId.replace('table_sector_', '');
                this._set(allData, `sector.${icao}`, this.extractSectorData(table));
            } else if (tableId.startsWith('table_winds_')) {
                const parts = tableId.replace('table_winds_', '').split('_');
                const icao = parts[0];
                const index = parts[1];
                this._set(allData, `winds.${icao}.${index}`, this.extractWindsData(table));
            } else if (tableId.startsWith('table_solar_lunar_')) {
                const icao = tableId.replace('table_solar_lunar_', '');
                this._set(allData, `solar_lunar.${icao}`, this.extractSolarLunarData(table));
            } else if (tableId === 'table_header') {
                allData.header = this.extractHeaderData(table);
            } else if (tableId === 'table_space') {
                allData.space_weather = this.extractSpaceWeatherData(table);
            } else if (tableId === 'table_tafs') {
                allData.tafs = this.extractTafsData(table);
            }
        });

        // Process individual elements marked with '.savable-element'
        document.querySelectorAll('.savable-element').forEach(element => {
            const key = element.dataset.saveKey;
            if (!key) return;
            let value = (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA' || element.tagName === 'SELECT') ? element.value : element.textContent;
            this._set(allData, key, value);
        });
        
        // Process pasteable image containers
        document.querySelectorAll('.pasteable-container').forEach(p => {
            const suffix = p.dataset.suffix;
            if (!suffix) return;
            const label = p.querySelector(`#paste-target-${suffix}`).textContent;
            const images = Array.from(p.querySelectorAll('.image-container img')).map(img => img.src);
            this._set(allData, `pasteables.${suffix}`, { label, images });
        });

        return allData;
    }

    extractHeaderData(table) {
        const data = {};
        const rows = table.querySelectorAll('tr');
        data.title = rows[0]?.querySelector('th')?.textContent || '';
        data.disclaimer = rows[1]?.querySelector('th')?.textContent || '';
        const contactCell = rows[2]?.querySelector('td')?.innerHTML.split('<br>') || ['', ''];
        data.contact_info = contactCell[0];
        data.pmsv = contactCell[1];
        
        const mainDataCells = rows[4]?.querySelectorAll('td') || [];
        data.issue_time = mainDataCells[0]?.textContent || '';
        data.valid_time = mainDataCells[1]?.textContent || '';
        data.forecaster = mainDataCells[2]?.textContent || '';
        data.forecaster_phone = mainDataCells[3]?.textContent || '';
        data.flimsy_number = mainDataCells[4]?.textContent || '';

        const briefDataCells = rows[6]?.querySelectorAll('td') || [];
        data.brief_time = briefDataCells[0]?.textContent || '';
        data.void_time = briefDataCells[1]?.textContent || '';
        data.briefer_initials = briefDataCells[2]?.textContent || '';
        data.sdo_initials = briefDataCells[3]?.textContent || '';
        data.pilot_initials = briefDataCells[4]?.textContent || '';
        return data;
    }

    extractToldData(table) {
        const data = { forecasts: [] };
        data.header = table.querySelector('thead th.hd')?.textContent || '';
        const headers = Array.from(table.querySelectorAll('thead .titles')).map(th => th.textContent.toLowerCase().replace(/[^a-z0-9]/g, '_'));
        
        table.querySelectorAll('tbody tr').forEach(row => {
            const rowData = {};
            row.querySelectorAll('td').forEach((cell, index) => {
                if (cell.dataset.assetName) {
                    if (!rowData.impacts) rowData.impacts = {};
                    rowData.impacts[cell.dataset.assetName] = cell.textContent;
                } else {
                    const key = headers[index] || `column_${index}`;
                    rowData[key] = cell.textContent;
                }
            });
            data.forecasts.push(rowData);
        });
        return data;
    }

    extractSectorData(table) {
        const data = { forecasts: [] };
        const headerRow = table.querySelector('tr');
        data.station_name = headerRow?.cells[0]?.textContent || '';
        data.freezing_level = headerRow?.cells[2]?.textContent || '';

        table.querySelectorAll('tr:nth-child(n+3)').forEach(row => {
            const cells = row.cells;
            if (cells.length < 4) return;
            data.forecasts.push({
                time: cells[0].textContent,
                vis_wx_sky_cond: cells[1].textContent,
                hazards: cells[2].textContent,
                alstg: cells[3].textContent
            });
        });
        return data;
    }
    
    extractWindsData(table) {
        const data = { levels: [] };
        data.valid_time = table.querySelector('.hd')?.textContent.replace('Valid: ', '') || '';
        table.querySelectorAll('tr:nth-child(n+3)').forEach(row => {
            if (row.cells.length < 2) return;
            data.levels.push({
                fl_lvl: row.cells[0].textContent,
                winds_temp: row.cells[1].textContent
            });
        });
        return data;
    }

    extractSolarLunarData(table) {
        const data = [];
        table.querySelectorAll('tr:nth-child(n+2)').forEach(row => {
            const rowData = {};
            const cells = row.querySelectorAll('td');
            for (let i = 0; i < cells.length; i += 2) {
                const key = cells[i]?.textContent.replace(':', '').toLowerCase().trim() || `col_${i}`;
                rowData[key] = cells[i + 1]?.textContent || '';
            }
            data.push(rowData);
        });
        return data;
    }

    extractSpaceWeatherData(table) {
        const data = { contrails: {} };
        data.gps = table.querySelector('#gps').textContent || '';
        data.hf = table.querySelector('#hf').textContent || '';
        data.uhf = table.querySelector('#uhf').textContent || '';
        const cells = Array.from(table.querySelectorAll('td'));
        data.contrails.bases = cells.at(-2)?.textContent || '000';
        data.contrails.tops = cells.at(-1)?.textContent || '000';
        return data;
    }

    extractTafsData(table) {
        return Array.from(table.querySelectorAll('.TAF')).map(cell => this.cleanTAF(cell.textContent));
    }
}


// =================================================================================
// STANDALONE HELPER FUNCTIONS
// =================================================================================

/**
 * Triggers a browser download for the given data object as a JSON file.
 * This function is placed in the global scope to be accessible from an HTML event listener.
 */
function downloadJson(data, filename = 'forecast_data.json') {
    console.log(data);
    const jsonString = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = data.header.title + "_" + data.header.flimsy_number + "_" + data.header.valid_time + "_" + filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}


function findKeyInJsonList(jsonList, keyToFind) {
    if (!Array.isArray(jsonList) || typeof keyToFind !== 'string') {
        return false;
    }
    for (let i = 0; i < jsonList.length; i++) {
        const jsonObject = jsonList[i];
        if (typeof jsonObject === 'object' && jsonObject !== null && keyToFind in jsonObject) {
            return jsonObject;
        }
    }
    return false;
}

function findParameterInTimeseriesArray(timeseries, parameterName) {
    if (!Array.isArray(timeseries) || typeof parameterName !== 'string') {
        return false;
    }
    for (let i = 0; i < timeseries.length; i++) {
        const jsonObject = timeseries[i];
        if (typeof jsonObject === 'object' && jsonObject !== null && jsonObject.parameter == parameterName) {
            return jsonObject;
        }
    }
    return false;
}

function findValueOfHourOfParameter(timeseries, parameterName, hour) {
    let jsonObject = findParameterInTimeseriesArray(timeseries, parameterName);
    if (!jsonObject || !Array.isArray(jsonObject.values) || typeof hour !== 'number') {
        return 0; // Return a default value for safety
    }
    let values = jsonObject.values;
    for (let i = 0; i < values.length; i++) {
        const jsonObj = values[i];
        if (typeof jsonObj === 'object' && jsonObj !== null && jsonObj.hour == hour) {
            return jsonObj.value;
        }
    }
    return 0; // Return default if hour not found
}

function flWindsTemp(tarpDataByICAO, level, fhour) {
    if (!tarpDataByICAO) return { display: '' };
    let lvl = parseInt(level) * 100;
    let closest = 0;
    const heightList = ["1000mb", "975mb", "950mb", "925mb", "900mb", "875mb", "850mb", "825mb", "800mb", "775mb", "750mb", "725mb", "700mb", "675mb", "650mb", "625mb", "600mb", "575mb", "550mb", "525mb", "500mb", "475mb", "450mb", "425mb", "400mb", "375mb", "350mb", "325mb", "300mb", "275mb", "250mb", "225mb", "200mb", "175mb", "150mb", "125mb", "100mb"];
    let minDiff = Infinity;

    for (let i = 0; i < heightList.length; i++) {
        let concatVariable = "gph_" + heightList[i];
        let GPHHeight = Math.round(metersToFeet(findValueOfHourOfParameter(tarpDataByICAO, concatVariable, 0)));
        let diff = Math.abs(GPHHeight - lvl);
        if (diff < minDiff) {
            minDiff = diff;
            closest = heightList[i];
        }
    }

    let windSpdVar = "speed_" + closest;
    let windDirVar = "dir_" + closest;
    let tempVar = "temp_" + closest;

    let windSpd = padNumber(Math.round(findValueOfHourOfParameter(tarpDataByICAO, windSpdVar, fhour) / 5) * 5, 2);
    let windDir = padNumber(Math.round(findValueOfHourOfParameter(tarpDataByICAO, windDirVar, fhour) / 10) * 10, 3);
    let temp = temperature(findValueOfHourOfParameter(tarpDataByICAO, tempVar, fhour));
    let display = windDir + windSpd + "KT / " + (temp.C < 0 ? temp.C : "+" + temp.C) + "C";

    return {
        height_mb: closest,
        windSpd: windSpd,
        windDir: windDir,
        tempC: temp.C,
        display: display
    };
}

function padNumber(number, length) {
    return String(number).padStart(length, '0');
}

function addPlusSign(number) {
    if (number > 0) {
        return "+" + number;
    } else {
        return number.toString();
    }
}

function metricVisibility(vis) {
    if (vis > 6) return 9999;
    if (vis >= 5.5) return 9000;
    if (vis >= 4.5) return 8000;
    if (vis > 3.5) return 6000;
    if (vis >= 3) return 5000;
    return Math.round(parseInt(vis * 1600), 0);
}
