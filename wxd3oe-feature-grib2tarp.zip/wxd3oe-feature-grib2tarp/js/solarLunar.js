// =============================================================================
// solarLunar.js  —  Solar and lunar event calculator for the MEF tool
//
// Public API:
//   mefCalc(year, month, day, lat, lng, tzOffset)
//     Returns an array where:
//       [0]  = date string  "DD MMM YYYY"
//       [1]  = (unused placeholder)
//       [2]  = sunrise     "HHMM"
//       [3]  = sunset      "HHMM"
//       [4]  = (unused)
//       [5]  = (unused)
//       [6]  = BMNT        "HHMM"  (Begin Morning Nautical Twilight, 12°)
//       [7]  = EENT        "HHMM"  (End Evening Nautical Twilight, 12°)
//       [8]  = (unused)
//       [9]  = (unused)
//       [10] = (unused)
//       [11] = moonrise    "HHMM"
//       [12] = moonset     "HHMM"
//       [13] = illumination "XX%"
// =============================================================================

'use strict';

// ── Utilities ─────────────────────────────────────────────────────────────────

const _DEG = Math.PI / 180;
const _RAD = 180 / Math.PI;

function _toRad(d) { return d * _DEG; }
function _toDeg(r) { return r * _RAD; }

/** Reduce angle to [0, 360) */
function _norm360(a) { return ((a % 360) + 360) % 360; }

/** Julian Day Number from calendar date (UT) */
function _jd(Y, M, D) {
    if (M <= 2) { Y -= 1; M += 12; }
    const A = Math.floor(Y / 100);
    const B = 2 - A + Math.floor(A / 4);
    return Math.floor(365.25 * (Y + 4716)) + Math.floor(30.6001 * (M + 1)) + D + B - 1524.5;
}

/** Format decimal hours → "HHMM" string, or "----" if event doesn't occur */
function _fmt(h) {
    if (h === null) return '----';
    h = ((h % 24) + 24) % 24;          // normalise to [0,24)
    const hh = Math.floor(h);
    const mm = Math.round((h - hh) * 60);
    return String(hh).padStart(2, '0') + String(mm < 60 ? mm : 59).padStart(2, '0');
}

// ── Solar event calculation ────────────────────────────────────────────────────
// Based on the USNO algorithm / Meeus "Astronomical Algorithms" Ch. 15.

/**
 * Calculate the UTC hour of a solar event for the given date & location.
 * @param {number} jd0       Julian day at 0h UT for the date
 * @param {number} lat       Observer latitude (°)
 * @param {number} lng       Observer longitude (° east)
 * @param {number} zenith    Solar zenith angle at event (°)
 *                           90.833° = sunrise/sunset (accounts for refraction + disc)
 *                           96°     = civil twilight
 *                           102°    = nautical twilight
 *                           108°    = astronomical twilight
 * @param {boolean} rising   true = rising event, false = setting event
 * @returns {number|null}    UTC decimal hours, or null if sun never rises/sets
 */
function _solarEvent(jd0, lat, lng, zenith, rising) {
    const n    = jd0 - 2451545.0;        // days since J2000.0
    const L    = _norm360(280.46 + 0.9856474 * n);   // mean longitude
    const g    = _norm360(357.528 + 0.9856003 * n);  // mean anomaly (°)
    const lamb = _norm360(L + 1.915 * Math.sin(_toRad(g)) + 0.020 * Math.sin(_toRad(2 * g)));
    const eps  = 23.439 - 0.0000004 * n;             // obliquity
    const sinDec = Math.sin(_toRad(eps)) * Math.sin(_toRad(lamb));
    const dec    = _toDeg(Math.asin(sinDec));

    const cosH = (Math.cos(_toRad(zenith)) - sinDec * Math.sin(_toRad(lat)))
               / (Math.cos(_toRad(dec))    * Math.cos(_toRad(lat)));

    if (cosH > 1)  return null;   // sun never rises (below horizon all day)
    if (cosH < -1) return null;   // sun never sets

    const H = _toDeg(Math.acos(cosH));
    // RA of sun (approx)
    const sinLamb  = Math.sin(_toRad(lamb));
    const cosLamb  = Math.cos(_toRad(lamb));
    const cosEps   = Math.cos(_toRad(eps));
    const RA       = _toDeg(Math.atan2(cosEps * sinLamb, cosLamb)) / 15; // hours

    // local mean solar noon (UT)
    const lngHour  = lng / 15;
    const T0       = RA - lngHour - 6.697375 - 0.0657098 * n;
    const noon     = ((T0 % 24) + 24) % 24;

    const event = rising ? noon - H / 15 : noon + H / 15;
    return ((event % 24) + 24) % 24;
}

// ── Lunar calculations ────────────────────────────────────────────────────────
// Meeus Ch. 47 (simplified) + USNO moonrise/moonset algorithm

/** Moon's ecliptic longitude, latitude and distance for a given JD */
function _moonPos(jd) {
    const T  = (jd - 2451545.0) / 36525;
    const T2 = T * T;
    const T3 = T2 * T;

    let Lp = 218.3164477 + 481267.88123421 * T - 0.0015786 * T2 + T3 / 538841;
    let D  = 297.8501921 + 445267.1114034  * T - 0.0018819 * T2 + T3 / 545868;
    let M  = 357.5291092 +  35999.0502909  * T - 0.0001536 * T2 + T3 / 24490000;
    let Mp = 134.9633964 + 477198.8675055  * T + 0.0087414 * T2 + T3 / 69699;
    let F  = 93.2720950  + 483202.0175233  * T - 0.0036539 * T2 - T3 / 3526000;

    Lp = _norm360(Lp);  D = _norm360(D);
    M  = _norm360(M);   Mp= _norm360(Mp);  F = _norm360(F);

    // Longitude corrections (degrees)
    let sumL =
         6.288774 * Math.sin(_toRad(Mp))
       + 1.274027 * Math.sin(_toRad(2*D - Mp))
       + 0.658314 * Math.sin(_toRad(2*D))
       + 0.213618 * Math.sin(_toRad(2*Mp))
       - 0.185116 * Math.sin(_toRad(M))
       - 0.114332 * Math.sin(_toRad(2*F))
       + 0.058793 * Math.sin(_toRad(2*D - 2*Mp))
       + 0.057066 * Math.sin(_toRad(2*D - M - Mp))
       + 0.053322 * Math.sin(_toRad(2*D + Mp))
       + 0.045758 * Math.sin(_toRad(2*D - M));

    const lng = _norm360(Lp + sumL);

    // Latitude corrections
    let sumB =
         5.128122 * Math.sin(_toRad(F))
       + 0.280602 * Math.sin(_toRad(Mp + F))
       + 0.277693 * Math.sin(_toRad(Mp - F))
       + 0.173237 * Math.sin(_toRad(2*D - F))
       + 0.055413 * Math.sin(_toRad(2*D + F - Mp))
       + 0.046271 * Math.sin(_toRad(2*D - F - Mp))
       + 0.032573 * Math.sin(_toRad(2*D + F));

    const lat = sumB;  // degrees

    return { lng, lat };
}

/** Moon's declination and right ascension for a given JD */
function _moonDecRA(jd) {
    const eps = 23.439 - 0.0000004 * (jd - 2451545.0);
    const { lng, lat } = _moonPos(jd);
    const sinDec = Math.sin(_toRad(lat)) * Math.cos(_toRad(eps))
                 + Math.cos(_toRad(lat)) * Math.sin(_toRad(eps)) * Math.sin(_toRad(lng));
    const dec    = _toDeg(Math.asin(sinDec));
    const cosLng = Math.cos(_toRad(lng));
    const sinLng = Math.sin(_toRad(lng));
    const cosEps = Math.cos(_toRad(eps));
    const ra     = _norm360(_toDeg(Math.atan2(cosEps * sinLng, cosLng)));
    return { dec, ra };
}

/**
 * Moon phase illumination fraction for a given JD (0 = new, 1 = full).
 * Uses the elongation of the moon from the sun.
 */
function _moonIllumination(jd) {
    const T    = (jd - 2451545.0) / 36525;
    const D    = _norm360(297.8501921 + 445267.1114034 * T);
    const M    = _norm360(357.5291092 +  35999.0502909 * T);
    const Mp   = _norm360(134.9633964 + 477198.8675055 * T);
    const i    = 180
               - D
               - 6.289 * Math.sin(_toRad(Mp))
               + 2.100 * Math.sin(_toRad(M))
               - 1.274 * Math.sin(_toRad(2*D - Mp))
               - 0.658 * Math.sin(_toRad(2*D))
               - 0.214 * Math.sin(_toRad(2*Mp))
               - 0.110 * Math.sin(_toRad(D));
    return (1 + Math.cos(_toRad(i))) / 2;
}

/**
 * Iterative moonrise / moonset time finder.
 * Returns decimal UTC hours or null if the moon doesn't rise/set.
 */
function _moonEvent(jd0, lat, lng, rising) {
    const ZENITH = 90.833; // same horizon as sun (accounts for parallax ~0.95° + refraction)
    let   t      = rising ? 6 : 18;  // first guess (hours UT)

    for (let i = 0; i < 8; i++) {
        const jd  = jd0 + t / 24;
        const { dec, ra } = _moonDecRA(jd);
        const gst = _norm360(100.4606184 + 360.98564774 * (jd - 2451545.0) + lng) / 15;
        const lha = ((gst - ra / 15 + 24) % 24) * 15; // local hour angle in degrees

        const cosH = (Math.cos(_toRad(ZENITH)) - Math.sin(_toRad(dec)) * Math.sin(_toRad(lat)))
                   / (Math.cos(_toRad(dec))     * Math.cos(_toRad(lat)));

        if (Math.abs(cosH) > 1) return null;

        const H  = _toDeg(Math.acos(Math.max(-1, Math.min(1, cosH))));
        const HA = rising ? 360 - H : H;
        const dt = ((HA - lha + 360) % 360) / 15;
        t = (t + dt) % 24;
    }

    return ((t % 24) + 24) % 24;
}

// ── Public API ────────────────────────────────────────────────────────────────

const _MONTHS = ['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];

/**
 * Calculate solar and lunar events for a given date and location.
 *
 * @param {number} year
 * @param {number} month   1–12
 * @param {number} day     1–31
 * @param {number} lat     Latitude  (° north positive)
 * @param {number} lng     Longitude (° east positive, west negative)
 * @param {number} tzOff   UTC offset in hours (pass 0 for UTC output)
 * @returns {Array}  See module header for index definitions.
 */
function mefCalc(year, month, day, lat, lng, tzOff) {
    const jd0 = _jd(year, month, day);   // JD at 0h UT on this date

    // ── Solar events ──────────────────────────────────────────
    const sunrise  = _solarEvent(jd0, lat, lng, 90.833, true);
    const sunset   = _solarEvent(jd0, lat, lng, 90.833, false);
    const bmnt     = _solarEvent(jd0, lat, lng, 102,    true);   // nautical twilight (12°)
    const eent     = _solarEvent(jd0, lat, lng, 102,    false);

    // ── Lunar events ──────────────────────────────────────────
    const moonrise = _moonEvent(jd0, lat, lng, true);
    const moonset  = _moonEvent(jd0, lat, lng, false);
    const illum    = _moonIllumination(jd0 + 0.5);  // midday

    const illumPct = Math.round(illum * 100) + '%';

    const dateStr  = String(day).padStart(2, '0') + ' ' + _MONTHS[month - 1] + ' ' + year;

    const result = new Array(14).fill('----');
    result[0]  = dateStr;
    result[2]  = _fmt(sunrise  !== null ? sunrise  + tzOff : null);
    result[3]  = _fmt(sunset   !== null ? sunset   + tzOff : null);
    result[6]  = _fmt(bmnt     !== null ? bmnt     + tzOff : null);
    result[7]  = _fmt(eent     !== null ? eent     + tzOff : null);
    result[11] = _fmt(moonrise !== null ? moonrise + tzOff : null);
    result[12] = _fmt(moonset  !== null ? moonset  + tzOff : null);
    result[13] = illumPct;

    return result;
}
