# ML Bias Corrector

The ML Bias Corrector trains a neural network to identify and correct systematic errors (biases) in TARP model output. Runs entirely in the browser via TensorFlow.js — no Python, no GPU required.

## Concept

A **bias** is a consistent, repeatable model error — not random noise. For example, TARP may routinely over-forecast wind speed during afternoon heating. The corrector learns these patterns from historical obs-vs-forecast pairs and exports a correction model for use in the TAF Generator and MEF Tool.

The network predicts **deltas (Δ)** — the difference between TARP and observation — not absolute values. The corrected output is:

```
corrected_value = TARP_value + Δ
```

## Quick-Start Workflow

1. Load observations (**AF Form 3803 JSON** export or **raw METAR paste**) on the Data Manager tab
2. Load one or more **TARP CSV** files
3. Click **▶ Match Now** to pair obs with forecast hours
4. Configure the network on the **Train** tab (layers, epochs, learning rate)
5. Click **▶ Train** and monitor loss curves
6. Export `model.json` + `ml_meta.json` from the **Export Model** tab
7. Load both files into the **MEF Tool** or **TAF Generator**

## Data Sources

| Source | How to load |
|--------|-------------|
| AF Form 3803 JSON | Export from the AF Form 3803 tool; drag onto upload zone |
| Raw METARs | Paste text or drag `.txt`/`.obs` file; set year/month before parsing |
| TARP CSV | Same CSV format used across BOSkit; multiple runs can be loaded at once |

TARP CSV filename format: station identifier + model run timestamp (auto-detected by the matcher).

## Model Types

| Type | Description |
|------|-------------|
| Neural Network (TF.js) | Dense feed-forward network with ReLU activations; best for non-linear biases |
| Analytical — Linear | Simple linear regression; interpretable, fast |
| Analytical — Polynomial | Polynomial regression for curved relationships |
| Analytical — Binning | Lookup-table approach; groups inputs into bins |

Both types are exported as JSON and consumed identically by other BOSkit tools.

## Exported Files

| File | Contents |
|------|----------|
| `model.json` (+ `model.weights.bin` for NN) | Network architecture and trained weights |
| `ml_meta.json` | Normalization statistics, correction targets, feature list |

**Both files are required.** Without `ml_meta.json` the model cannot run even if weights are loaded.

## Offline Setup

`js/tf.min.js` is included in the repository for offline use. The tool checks for a local copy before falling back to the CDN.
