# CI/CD & Security

## Pipeline Overview

The project uses a GitLab CI/CD pipeline defined in `.gitlab-ci.yml`. It runs two security scanning jobs on every push:

| Job | Template | Purpose |
|-----|----------|---------|
| `sast` | `Security/SAST.gitlab-ci.yml` | Static Application Security Testing — scans JavaScript and HTML for vulnerabilities using Semgrep |
| `secret_detection` | `Security/Secret-Detection.gitlab-ci.yml` | Scans commit history for accidentally committed secrets, tokens, and credentials |

## SAST Configuration

```yaml
variables:
  SAST_EXCLUDED_PATHS: "js/d3.min.js, js/tf.min.js, js/purify.min.js"
```

Third-party vendored libraries are excluded to avoid false positives from minified code.

## Viewing Results

- **GitLab Ultimate**: Results appear in **Security → Vulnerability Report** with full triage workflow
- **Free / Premium**: Jobs still run and produce `gl-sast-report.json` artifacts — download from the pipeline job page under **Artifacts**

## Runner Requirements

SAST jobs pull Docker images to run scans. The GitLab Runner must:
1. Have Docker installed
2. Use the `docker` executor
3. Have the `gitlab-runner` user in the `docker` group

See [Setting Up a Runner](https://docs.gitlab.com/runner/install/) for setup instructions.

## Adding More Scanners

To add dependency scanning or container scanning, add the relevant template to the `include` block in `.gitlab-ci.yml`:

```yaml
include:
  - template: Security/SAST.gitlab-ci.yml
  - template: Security/Secret-Detection.gitlab-ci.yml
  - template: Security/Dependency-Scanning.gitlab-ci.yml   # add if needed
```
