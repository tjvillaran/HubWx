# MEF Tool

The MEF Tool generates a formatted, print-ready Mission Execution Forecast (MEF) paper from TARP CSV data and a unit configuration file. All cells are directly editable. Sessions are auto-saved in `localStorage`.

## Quick-Start Workflow

1. Load your **Config JSON** (`📂 Config`)
2. Load one or more **TARP CSV** files (`📂 TARP`)
3. Optionally load an **Asset Config** for aircraft threshold color-coding
4. Optionally enable **ML Bias Correction** (`📂 ml_model.json` + `ml_meta.json`)
5. Click **▶ Stage MEF**
6. Edit cells, paste TAFs, add synoptic discussion
7. **⬇ Save JSON** to archive or **🖨 Print**

## Key Features

### ML Bias Correction
Load a trained model from the [ML Bias Corrector](ML-Bias-Corrector) to auto-correct TARP values before staging. Toggle the **🧠** switch to enable/disable. Raw TARP values are used when the switch is off or no model is loaded.

### MEF Numbering
Format: `DD + Letter` — day of month plus a letter suffix incrementing with each amendment (e.g. `31A`, `31B`). Displayed in the header and on the tab bar chip.

### TOLD Tables
One table per ICAO in the `TOLDS` config field. Pre-filled from TARP data. If an Asset Config is loaded, cells are color-coded green/amber/red against each aircraft's operating limits.

### TAF Cells
Paste raw TAFs into the Local TAFs section — the tool auto-cleans formatting and removes redundant groups.

### Solar/Lunar Block
Auto-computed from station coordinates in the config. No TARP data required. Two layout styles selectable via `solarStyle` in the config.

### Image Paste Zones
Named zones (e.g. Turbulence, Icing, SIGWX) accept pasted or dragged images. Images are embedded in the MEF and print with it.

## Save & Load

| Action | Result |
|--------|--------|
| **⬇ Save JSON** | Exports `MEF_31C_2025-03-31.json` with full paper HTML, config, and TARP data embedded |
| **📂 Load JSON** | Restores a previously saved MEF; prompts for amendment flag |

## Amendments
When loading a saved MEF, answering **Yes** to the amendment prompt increments the letter suffix (`31A` → `31B`) and logs the amendment in the header.

## Config File Reference

The `config.json` defines station names, issue times, sectors, TAF ICAOs, TOLD ICAOs, flight levels, solar stations, and asset types. See [Asset Manager](Asset-Manager) for the GUI editor.
