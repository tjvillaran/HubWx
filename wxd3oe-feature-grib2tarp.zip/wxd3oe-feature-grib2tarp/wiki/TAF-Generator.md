# TAF Generator

The TAF Generator is a Terminal Aerodrome Forecast builder with IntelliSense autocomplete. It loads TARP CSV guidance, optionally applies ML bias corrections, validates AFMAN 15-124 format and weather rule compliance, and exports finished TAFs.

## Features

- **IntelliSense autocomplete** — suggests valid weather codes, wind formats, and visibility values as you type
- **AFMAN 15-124 validation** — flags format errors and rule violations inline
- **TARP data pre-fill** — loads model guidance directly into the editor as a starting point
- **ML bias correction** — same correction model used by the MEF Tool; load `ml_model.json` + `ml_meta.json` to apply
- **TAF export** — copies finished TAFs to clipboard or downloads as plain text

## Loading TARP Data

Load a TARP CSV file from the sidebar. The tool reads wind, visibility, ceiling, temperature, and altimeter for each forecast hour. With ML bias correction enabled, corrected values replace raw TARP values before display.

## ML Bias Correction

See [ML Bias Corrector](ML-Bias-Corrector) for how to train and export a model. Load both `ml_model.json` and `ml_meta.json` to activate corrections. Toggle the **🧠** switch to compare corrected vs. raw guidance.

## Validation

The editor highlights invalid groups in real time. Common checks:
- Wind format (`dddffKT`, `dddffGggKT`, `VRB`)
- Visibility units (SM vs. metres)
- Ceiling descriptor (`BKN`, `OVC`, `FEW`, `SCT`)
- TEMPO/BECMG/FM/PROB ordering and time logic
- Mandatory elements per AFMAN 15-124
