# BOSkit — Integrated Forecast Operations Suite

BOSkit is a collection of browser-based weather tools for tactical aviation forecast operations. All tools run entirely in the browser — no server, no internet connection required after initial setup. Files never leave your machine.

## Tool Index

| Tool | Description |
|------|-------------|
| [AF Form 3803](AF-Form-3803) | Digital surface weather observation form |
| [ML Bias Corrector](ML-Bias-Corrector) | Train a neural network to correct TARP model bias |
| [TAF Generator](TAF-Generator) | IntelliSense TAF builder with AFMAN 15-124 validation |
| [TAF Monitor](TAF-Monitor) | Live countdown and status board for active TAFs |
| [Meteogram](Meteogram) | Upper-air / surface cross-section from TARP CSV |
| [5-Day Forecast](5-Day-Forecast) | Grid-based planning display with RAG asset assessment |
| [WX Grade](WX-Grade) | Forecast verification and A–F letter grading |
| [MEF Tool](MEF-Tool) | Mission Execution Forecast builder and printer |
| [Asset Manager](Asset-Manager) | Aircraft threshold config editor |
| [WWA Manager](WWA-Manager) | Watches, Warnings & Advisories dashboard |
| [DAFIF Map](DAFIF-Map) | Interactive DAFIF airport / navaid / waypoint plotter |
| [Weather Draw](Weather-Draw) | Map-based weather analysis drawing and annotation |
| [Skew-T](Skew-T) | Thermodynamic diagram for upper-air sounding analysis |
| [DD Form 175-1](DD-Form-175-1) | Digital flight weather briefing form |
| [GFS Downloader](GFS-Downloader) | GFS model data downloader |

## Typical Forecast Workflow

```
AF Form 3803       →  collect surface observations
ML Bias Corrector  →  train correction model from obs vs. TARP
TAF Generator      →  build TAFs with ML-corrected TARP guidance
MEF Tool           →  stage Mission Execution Forecast from TAFs + TARP
WX Grade           →  verify yesterday's forecasts, score A–F
```

## Getting Started

See [Getting Started](Getting-Started) for deployment and offline setup instructions.

## CI/CD & Security

See [CI-CD](CI-CD) for pipeline and SAST configuration details.
