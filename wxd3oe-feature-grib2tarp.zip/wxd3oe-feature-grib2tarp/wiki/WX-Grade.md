# WX Grade

WX Grade is a forecast verification tool for aviation weather. It compares forecast data against observations, scores accuracy across up to eight meteorological variables, and produces a print-ready verification report.

## Quick-Start Workflow

1. Load forecast data via the **Ingest** tab (TAF, JSON, CSV, or MEF JSON)
2. Load observation data (METAR paste, CSV, or AF Form 3803 JSON)
3. Click **▶ Grade Forecasts**
4. Review results on the **Grade** tab or print from the **Report** tab

## Data Ingest Methods

| Method | Input | Notes |
|--------|-------|-------|
| Forecast JSON | Custom JSON array | Supports `label` field for version naming |
| TAF paste | Raw ICAO TAF text | Handles FM, BECMG, TEMPO, PROB, TX/TN, A#### and QNH####INS |
| METAR paste | Raw METAR text | Auto-routes by ICAO identifier |
| CSV | Comma-separated forecast or obs | Select Forecast or Observations from dropdown first |
| MEF JSON | Full MEF Tool export | Extracts TOLD tables; uses `mef_number` as version label |

## Grading Systems

Select a system on the **Config** tab before running.

### Default (Weighted Average → Letter Grade)
Each forecast period is scored as a weighted average across variables. Letter grades: A (≥90), B (80–89), C (70–79), D (60–69), F (<60).

### ICAO Annex 3
Binary PASS/FAIL per element based on ICAO Annex 3 Table A7.1. Present weather uses Critical Success Index (CSI). TEMPO groups scored against observations within the window.

### Tricolor Block
Each element receives green/amber/red per period instead of a numeric score. Configurable thresholds per ceiling/vis category. Wind split threshold configurable (default 15 kt).

## Filtering Results

When multiple stations or MEF versions are present, filter dropdowns appear above the Grade and Report views:
- **Station** — filter to a single ICAO
- **Forecaster** — filter by forecaster name from MEF header
- **MEF Title** — filter by MEF title from MEF header

Filters update grade and report views live without re-running the grader. Click **✕ Clear** to reset.

## Export

| Action | Output |
|--------|--------|
| **🖨 Print Report** | Sends the Report tab to the browser print dialog; hides UI chrome |
| **Export CSV** | `forecast_grade_report.csv` — one row per graded period per station/version |
