# DAFIF Map

The DAFIF Map tool plots Digital Aeronautical Flight Information File (DAFIF) data on an interactive world map. Load airports, navaids, or waypoints from NGA tab-delimited files and visualize them with color-coded symbols. Files never leave your machine.

## Quick Start

1. Click **📂 Load DAFIF Files** in the sidebar
2. Select one or more `.txt` DAFIF files (hold Ctrl/⌘ for multiple)
3. The map auto-fits to display all loaded data

## Supported File Types

Auto-detected from the header row:

| Type | Detected by column |
|------|--------------------|
| Airports (APT) | `ARPT_IDENT` |
| Navaids (NAV) | `NAV_IDENT` |
| Waypoints (WPT) | `WPT_IDENT` |

### Navaid symbols by `NAV_TYPE`
VOR, TACAN, NDB, and DME each render with a distinct shape and color.

## Getting DAFIF Data

DAFIF is published by the National Geospatial-Intelligence Agency (NGA) on the 28-day AIRAC cycle. Full global dataset access requires DoD authorization.

**Using FAA NASR data instead:** Rename the following columns in the header row to match DAFIF format, then save as tab-delimited text:

| FAA NASR column | DAFIF equivalent |
|-----------------|-----------------|
| `SITE_NO` | `ARPT_IDENT` |
| *(refer to NASR docs)* | *(match key columns)* |

This can be done in any spreadsheet application — open, edit the header row, save as tab-delimited.

## Navigation

| Action | How |
|--------|-----|
| Pan | Click and drag |
| Zoom | Scroll wheel or pinch |
| Fit to data | **⊞ Fit to Data** button |
| Cursor coordinates | Bottom-left status bar (lat/lon + zoom level) |

## Layers Panel

Each loaded file becomes a named layer with a feature count and visibility toggle. Hidden layers are excluded from fit-to-data and click/hover hit tests.

## Search

Type 2+ characters to search across all visible layers simultaneously. Matches on identifier, name, and type (case-insensitive, substring). Click any result to fly to that feature. Up to 40 results shown — add more characters to narrow results.

## Feature Details

Hover within ~12 screen pixels of a feature to see a tooltip (identifier, name, type). Click to pin and expand full DAFIF record details in the sidebar. Click again or click empty map area to deselect.
