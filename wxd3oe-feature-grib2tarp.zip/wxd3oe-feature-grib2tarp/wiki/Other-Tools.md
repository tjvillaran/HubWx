# Other Tools

Quick reference for the remaining BOSkit tools.

---

## AF Form 3803

Digital AF Form 3803 Surface Weather Observation form. Structured entry for all weather parameters — ceiling, visibility, temperature, winds, and present weather codes. Exports JSON for use as training data in the [ML Bias Corrector](ML-Bias-Corrector) and as observation input for [WX Grade](WX-Grade).

---

## TAF Monitor

Live status board for active TAFs. Displays expiry countdowns, amendment status, and issuance timestamps. Color-coded by urgency. Useful as a passive awareness display during operations.

---

## Meteogram

Interactive time-pressure cross-section built from TARP CSV data. Panels include:
- Upper-air RH and cloud layers with wind barbs
- Surface temperature, altimeter, precipitation, and wind speed

Load a TARP CSV file from the sidebar to generate. Hover over the diagram for values at a specific time and level.

---

## 5-Day Forecast

Grid-based 5-day weather planning display. Features:
- Interactive weather picker dropdowns per day
- Wind compass inputs
- Red/Amber/Green (RAG) impact assessment per aircraft asset type per day

Useful for mission planning briefs and weekly forecast products.

---

## Asset Manager

GUI editor for the shared `config.json` asset library. Add and edit aircraft types, define mission types, set weather operating thresholds (ceiling, visibility, winds, LLWS, icing, turbulence, temperature), and manage present weather codes. Import/export `config.json` directly.

The exported `config.json` is consumed by the MEF Tool, TAF Generator, and 5-Day Forecast.

---

## WWA Manager

Watches, Warnings & Advisories (WWA) dashboard. Features:
- Live expiry countdowns with 15-minute pre-expiry alerts
- Color-coded status by severity
- Full issue / extend / cancel / verify / close workflow
- JSON import and export for persistence between sessions

---

## Weather Draw

Interactive map-based weather analysis drawing tool. Plot:
- Fronts (cold, warm, occluded, stationary)
- Thunderstorm areas
- Icing and cloud regions
- Annotated WX symbols (TSTM, CB, FZRA, FG, etc.) with top/bottom labels (e.g. MT 350, TS ISOLD) inside drawn polygons

Export and import GeoJSON and KML/KMZ.

---

## Skew-T

Interactive Skew-T Log-P thermodynamic diagram for upper-air sounding analysis. Displays temperature, dewpoint, and winds. Derives and displays:
- CAPE / CIN
- LCL / LFC
- Freezing levels
- Aviation hazard indices for turbulence, icing, and convection

---

## DD Form 175-1

Digital DD Form 175-1 Flight Weather Briefing form. Pre-fills from TARP CSV data. Fill in remaining fields and print or save as PDF for aircrew briefings.

---

## GFS Downloader

Downloads Global Forecast System (GFS) model data. Select a region, pressure levels, and forecast hours, then download the data files for use in other tools or external analysis software.
