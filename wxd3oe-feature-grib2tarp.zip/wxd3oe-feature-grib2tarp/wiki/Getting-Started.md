# Getting Started

## Requirements

- A modern browser (Chrome, Edge, or Firefox recommended)
- No server, backend, or internet connection required at runtime
- TensorFlow.js (`js/tf.min.js`) must be present for ML features

## Deployment Options

### Option 1 — Open files directly
Clone or download the repository and open `index.html` in your browser. All tools work from the local filesystem.

```bash
git clone https://sync.git.mil/john.delaney.7/wxd3oe.git
cd wxd3oe
# Open index.html in your browser
```

### Option 2 — Serve from a local web server
If your browser blocks local file access (e.g. for `fetch()` calls), serve the directory with any static file server:

```bash
# Python 3
python3 -m http.server 8080
# Then open http://localhost:8080
```

### Option 3 — Host on an intranet
Copy the entire repository directory to any static web server (Apache, Nginx, IIS). No server-side configuration is needed.

## Offline Setup for ML Features

The ML Bias Corrector and MEF Tool use TensorFlow.js. The file `js/tf.min.js` is included in the repository for offline use. No CDN access is required.

## File Dependencies

Most tools depend on external data files you supply at runtime:

| File type | Description | Used by |
|-----------|-------------|---------|
| TARP CSV | Model forecast output (winds, vis, cig, temp, etc.) | MEF Tool, TAF Generator, Meteogram, 5-Day Forecast |
| `config.json` | Unit asset and station configuration | MEF Tool, TAF Generator |
| `ml_model.json` + `ml_meta.json` | Trained bias correction model | MEF Tool, TAF Generator |
| DAFIF `.txt` files | Airport / navaid / waypoint data (NGA) | DAFIF Map |
| AF Form 3803 JSON export | Observation records | ML Bias Corrector, WX Grade |

## Session Persistence

All tools that support save/restore use the browser's `localStorage`. Your work survives a page reload on the same machine and browser, but does not sync between devices. Use the **Save JSON** / **Export** functions in each tool to create portable backups.
